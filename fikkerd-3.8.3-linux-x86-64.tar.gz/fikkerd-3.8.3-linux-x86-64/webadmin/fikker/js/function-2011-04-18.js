﻿var BT="";
var BL="";
//=============================================================
//判断浏览器
var Sys = {};
var ua = navigator.userAgent.toLowerCase();
if (window.ActiveXObject)
	Sys.ie = ua.match(/msie ([\d.]+)/)[1];
	else if (document.getBoxObjectFor)
    	Sys.firefox = ua.match(/firefox\/([\d.]+)/)[1];
	//else if (window.MessageEvent && !document.getBoxObjectFor)
		//Sys.chrome = ua.match(/chrome\/([\d.]+)/)[1];
	else if (window.opera)
		Sys.opera = ua.match(/opera.([\d.]+)/)[1];
	else if (window.openDatabase)
		Sys.safari = ua.match(/version\/([\d.]+)/)[1];
//=============================================================
//捕捉鼠标当前位置
function getMousePosition(){	
	var e=window.event;
	var m=(e.pageX || e.pageY)?{ x:e.pageX, y:e.pageY } : { x:e.clientX + document.documentElement.scrollLeft - document.documentElement.clientLeft, y:e.clientY + document.documentElement.scrollTop  - document.documentElement.clientTop };
	return m;
}
//=============================================================
//获取返回对象的STYLE参数
function getAbsoluteCoords (e) {
	var t = e.offsetTop; var l = e.offsetLeft; var w = e.offsetWidth; var h = e.offsetHeight;
	while  (e=e.offsetParent) { t += e.offsetTop; l += e.offsetLeft; }; 
	return { top: t, left: l, width: w, height: h, bottom: t+h, right: l+w };
}
//=============================================================
//LEFT,RIGHT,MID,LEN函数
function left(mainStr,lngLen){ 
	if (lngLen>0) {return mainStr.substring(0,lngLen);}
	else{return null;}
} 
function right(mainStr,lngLen){ 
	if (mainStr.length-lngLen>=0 && mainStr.length>=0 && mainStr.length-lngLen<=mainStr.length) { 
	return mainStr.substring(mainStr.length-lngLen,mainStr.length);} 
	else{return null;}
} 
function mid(mainStr,starnum,endnum){ 
	if (mainStr.length>=0){ 
	return mainStr.substr(starnum,endnum);
	}else{return null;} 
}
function len(s){ 
	var l = 0; 
	var a = s.split(""); 
	for (var i=0;i<a.length;i++) { 
		if(a[i].charCodeAt(0)<299) { 
			l++; 
		}else{ 
			l+=2; 
		} 
	}
	return l; 
}
//=============================================================
//在实时监控中，如果多开浏览器会处于等待状态，增加随机数以解决此问题
function GetRandomNum(Min,Max){
	var Range = Max - Min;  
	var Rand = Math.random();  
	return(Min + Math.round(Rand * Range));
}
//=============================================================
//功能页面的图片反转及iframe地址改变函数
function changeiframeURL(imgNAME,imgID,iframeID,inputURL){
	for(var i=1;i<8;i++){
		var tmpbuttonID=imgNAME+"-button"+i;
		if(document.getElementById(tmpbuttonID))document.getElementById(tmpbuttonID).src="image/"+imgNAME+"-button"+i+"b.gif";
	}
	document.getElementById(imgNAME+"-button"+imgID).src="image/"+imgNAME+"-button"+imgID+"a.gif";
	document.getElementById(iframeID).src=inputURL;
}

function changeParentSelectButton(imgNAME,imgID){//在进行F5刷新时，设置BUTTON同步修改
	try{
		for(var i=1;i<8;i++){
			var tmpbuttonID=imgNAME+"-button"+i;
			if(parent.document.getElementById(tmpbuttonID))parent.document.getElementById(tmpbuttonID).src="image/"+imgNAME+"-button"+i+"b.gif";
		}
		parent.document.getElementById(imgNAME+"-button"+imgID).src="image/"+imgNAME+"-button"+imgID+"a.gif";
	}
	catch(e){}
}

//=============================================================
//用于行的上下移操作
function moveUp(ACTNAME,clickID,MSGID){		//上移：操作，当前ID，提示ID
		var clickROW=document.getElementById(ACTNAME+clickID+"TR");
		var getChangeROW=0;					//是否已经获得交换行
		var tmpOBJ;
		var i=0;

		if(clickROW.previousSibling){								//判断当前是否为第一行
			while(getChangeROW==0){
				if(i==0){
					tmpOBJ=clickROW.previousSibling;
				}else{
					tmpOBJ=tmpOBJ.previousSibling;
				}
				if(tmpOBJ.nodeType==1){
					var tmpOBJID=tmpOBJ.id;
					//alert(tmpOBJID+"CSS"+tmpSTYLE);
					if(tmpOBJID.indexOf(ACTNAME)!=-1){
						getChangeROW=1;
						var TR1=clickROW;
						var TR2=document.getElementById(tmpOBJID);
						//alert("交换行ID为："+TR1.id+" "+TR2.id);
						swapNode(TR1,TR2);							//进行交换
						resetIndexNO(ACTNAME,'0',1);					//重新排序
						var boxURL="msg.htm?"+MSGID;		//操作成功，进行提示（因为FIKKER在第一行或者最后一行时进行移动仍然返回TRUE，所以在此进行判断）
						showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
					}
				}
				i=i+1;
			}
		}else{
			var boxURL="msg.htm?0.1";						//已是第一行
			showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		}
}

function moveDown(ACTNAME,clickID,MSGID){		//下移：操作，当前ID，提示ID
	var clickROW=document.getElementById(ACTNAME+clickID+"TR");
	var getChangeROW=0;							//是否已经获得交换行
	var tmpOBJ;
	var i=0;
	var lastNode=0;
	while(getChangeROW==0){
		if(i==0){
			try{tmpOBJ=clickROW.nextSibling;}
			catch(err){
				//alert("已是最后一行1");
				lastNode=1;
				getChangeROW=1;
			}
		}else{
			try{tmpOBJ=tmpOBJ.nextSibling;}
			catch(err){
				//alert("已是最后一行2");
				lastNode=1;
				getChangeROW=1;
			}
		}
		if(lastNode==1){
			var boxURL="msg.htm?0.2";					//已是最后行
			showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		}
		
		if(getChangeROW==0){
			if(tmpOBJ.nodeName.indexOf("LISTEND")!=-1){
				lastNode=1;
				getChangeROW=1;
				//alert("已是最后一行3");	
				var boxURL="msg.htm?0.2";				//已是最后行
				showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
			}else{
				if(tmpOBJ.nodeType==1){
					var tmpOBJID=tmpOBJ.id;
					//alert(tmpOBJ.id);alert(tmpOBJ.nodeName);alert(tmpOBJ.nodeType);
					//alert(tmpOBJID+"CSS"+tmpSTYLE);
					if(tmpOBJID.indexOf(ACTNAME)!=-1){
						//交换两行，内容行和LINE行
						getChangeROW=1;
						var TR1=document.getElementById(ACTNAME+clickID+"TR");
						var TR2=tmpOBJ;
						//alert("交换行ID为："+TR1.id+" "+TR2.id);
						swapNode(TR1,TR2);							//进行交换
						resetIndexNO(ACTNAME,'0',1);					//重新排序
						var boxURL="msg.htm?"+MSGID;		//操作成功，进行提示
						showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
					}
				}
			}
		}
		i=i+1;
	}
}

function swapNode(node1,node2){
	//获取父结点
	var _parent=node1.parentNode;
	//获取两个结点的相对位置
	var _t1=node1.nextSibling;
	var _t2=node2.nextSibling;
	//将node2插入到原来node1的位置
	if(_t1)_parent.insertBefore(node2,_t1);
	else _parent.appendChild(node2);
	//将node1插入到原来node2的位置
	if(_t2)_parent.insertBefore(node1,_t2);
	else _parent.appendChild(node1);
}

//=============================================================
//重新排序:动作，是否父级页面，每条记录行数（有子集项目应用此功能）在进行上下移动 和删除时，执行本函数
function resetIndexNO(ACTNAME,ifParent,lineNO){		
	if(ifParent==0){
		var strTAB=document.getElementById(ACTNAME+"TAB");
	}else{
		var strTAB=parent.document.getElementById(ACTNAME+"TAB");
	}
	var nowLineNO=strTAB.rows.length;//获取当前行数
	//alert(nowLineNOtmp);
	if(nowLineNO>=lineNO){//一条记录为3行，小于3行则无记录
		for(var i=0;i<nowLineNO;i=i+lineNO){
			var strID=strTAB.rows[i].id.replace(ACTNAME,"").replace("TR","");
			var strTDID=ACTNAME+"IndexNO"+strID+"TD";
			if(i==0){
				var strIndexNO=1;
			}else{
				var strIndexNO=(i/lineNO)+1;
			}
			if(ifParent==0){
				if(document.getElementById(strTDID))document.getElementById(strTDID).innerHTML=strIndexNO;
			}else{
				if(parent.document.getElementById(strTDID))parent.document.getElementById(strTDID).innerHTML=strIndexNO;
			}

		}

	}
}
//=============================================================
//以下为对公用错误提示的处理
function chkErr(errID){
	var msgURL="";
	if(errID==10)msgURL="msg.htm?0.3";
	if(errID==11)msgURL="msg.htm?0.4";
	if(errID==12)msgURL="msg.htm?0.5";
	if(errID==20)msgURL="msg.htm?0.6";
	if(errID==21)msgURL="msg.htm?0.7";
	if(errID==22)msgURL="msg.htm?0.8";
	if(errID==23)msgURL="msg.htm?0.9";
	return msgURL;
}
//=============================================================
//以下为对AJAX返回值的处理
//登录验证
function chkLogin(ReturnData){						
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?1.1";
		showMSGBOX('',350,100,220,BL,120,boxURL,'登录信息:');
		}else{
			addCookie("FIKKERSERRIONID",ReturnData.SessionID,0);
			addCookie("FIKKERUSERTYPE",ReturnData.UserType,0);
			addCookie("FIKKERVERISON",ReturnData.Version,0);
			if(parent==null){
				location.href="default.htm";
			}else{
				parent.location.href="default.htm";
			}
			//alert(SessionID);
	}
}
//===========================================================================================================
//以下为实时监控部分
function setMEMSize(nowSIZE){
	nowSIZE=parseInt(nowSIZE);
	if(nowSIZE<1024){
		return nowSIZE+" KB";
	}else if(nowSIZE>1024*1024){
		nowSIZE=(nowSIZE/(1024.00*1024.00)).toFixed(2) +" GB";
		return nowSIZE;
	}else{
		nowSIZE=(nowSIZE/1024.00).toFixed(2) +" MB";
		return nowSIZE;
	}
}
function realtimelist(ReturnData){					//实时监控列表
	if(ReturnData.Return=="False"){
		if(document.getElementById("realtimeButton"))document.getElementById("realtimeButton").src="image/button-realtime-reload-start.gif";//如果处于自动刷新状态则停止
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?1.2";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		if(document.getElementById("StartTime"))document.getElementById("StartTime").innerHTML=ReturnData.StartTime;
		if(document.getElementById("CurrentTime"))document.getElementById("CurrentTime").innerHTML=ReturnData.CurrentTime;
		if(document.getElementById("CurrentUserConnections"))document.getElementById("CurrentUserConnections").innerHTML=ReturnData.CurrentUserConnections;
		if(document.getElementById("CurrentUpstreamConnections"))document.getElementById("CurrentUpstreamConnections").innerHTML=ReturnData.CurrentUpstreamConnections;
		if(document.getElementById("AllUsedMemSize"))document.getElementById("AllUsedMemSize").innerHTML=setMEMSize(ReturnData.AllUsedMemSize);
		if(document.getElementById("CacheUsedMemSize"))document.getElementById("CacheUsedMemSize").innerHTML=setMEMSize(ReturnData.CacheUsedMemSize);
		if(document.getElementById("NumOfCaches"))document.getElementById("NumOfCaches").innerHTML=ReturnData.NumOfCaches;
		if(document.getElementById("TotalSendKB"))document.getElementById("TotalSendKB").innerHTML=setMEMSize(ReturnData.TotalSendKB);
		if(document.getElementById("TotalRecvKB"))document.getElementById("TotalRecvKB").innerHTML=setMEMSize(ReturnData.TotalRecvKB);
		if(document.getElementById("NumOfCachedSessions"))document.getElementById("NumOfCachedSessions").innerHTML=ReturnData.NumOfCachedSessions;
		if(document.getElementById("NumOfPublicCaches"))document.getElementById("NumOfPublicCaches").innerHTML=ReturnData.NumOfPublicCaches;
		if(document.getElementById("NumOfMemberCaches"))document.getElementById("NumOfMemberCaches").innerHTML=ReturnData.NumOfMemberCaches;
		if(document.getElementById("PublicCacheUsedMemSize"))document.getElementById("PublicCacheUsedMemSize").innerHTML=setMEMSize(ReturnData.PublicCacheUsedMemSize);
		if(document.getElementById("MemberCacheUsedMemSize"))document.getElementById("MemberCacheUsedMemSize").innerHTML=setMEMSize(ReturnData.MemberCacheUsedMemSize);
		if(document.getElementById("NumOfVisitorCaches"))document.getElementById("NumOfVisitorCaches").innerHTML=ReturnData.NumOfVisitorCaches;
		if(document.getElementById("VisitorCacheUsedMemSize"))document.getElementById("VisitorCacheUsedMemSize").innerHTML=setMEMSize(ReturnData.VisitorCacheUsedMemSize);
	}
}
function realtimetotalstat(ReturnData){			//获取实时总量统计报告
	if(ReturnData.Return=="False"){
		document.getElementById("realtimeButton").src="image/button-realtime-reload-start.gif";//如果处于自动刷新状态则停止
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?1.3";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		//alert(ReturnData.RealTimeReport);
		document.getElementById("StartTime").innerHTML=ReturnData.StartTime;
		document.getElementById("EndTime").innerHTML=ReturnData.EndTime;
		document.getElementById("HitCachesRate").innerHTML=ReturnData.HitCachesRate;
		var RealTimeReport=ReturnData.RealTimeReport;
		
		RealTimeReport=RealTimeReport.split("\r\n");
		var RealTimeReportTAB="";
		for (var i=1;i<RealTimeReport.length-1;i++){
				var tmpChar=RealTimeReport[i];
				tmpChar=tmpChar.replace(new RegExp("\ +","g"),"|");
				tmpChar=tmpChar.replace(new RegExp("[A-Za-z0-9_|\|]?$","g"),"");
				tmpChar=tmpChar.replace("|","<td>");
				tmpChar=tmpChar.replace(new RegExp("[\|]","g"),"</td><td>");
				tmpChar=tmpChar+"</td>";
				
				tmpChar="<tr class=\"normal\" height=\"20\" onMouseOver=\"javascript:this.style.backgroundColor='#EFF5FB'\" onMouseOut=\"javascript:this.style.backgroundColor='#FFFFFF'\">"+"\n"+"	<td align=\"center\">"+i+"</td>" + tmpChar + "\n" + "</tr>"+"\n";
				tmpChar=tmpChar+"<tr><td width=\"100%\" colspan=\"6\" height=\"5\" background=\"image/line-5px.gif\"></td><td></td></tr>"+"\n";
				//if(i==1){alert(tmpChar)}
				RealTimeReportTAB=RealTimeReportTAB+tmpChar;
		}
		var tmpTab="<table width=\"660\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n";
		tmpTab=tmpTab+"	<tr class=\"pTitle\" height=\"25\">"+"\n";
		tmpTab=tmpTab+"		<td width=\"60\" align=\"center\">序号</td>"+"\n";
		tmpTab=tmpTab+"		<td width=\"120\">省份</td>"+"\n";
		tmpTab=tmpTab+"		<td width=\"120\">总请求量TR</td>"+"\n";
		tmpTab=tmpTab+"		<td width=\"120\">独立IP访问量</td>"+"\n";
		tmpTab=tmpTab+"		<td width=\"120\">人均请求数量</td>"+"\n";
		tmpTab=tmpTab+"		<td width=\"120\">流量百分比%</td>"+"\n";
		tmpTab=tmpTab+"		<td></td>"+"\n";
		tmpTab=tmpTab+"	</tr>"+"\n";
		tmpTab=tmpTab+"	<tr><td height=\"1\" colspan=\"6\" bgcolor=\"#A7C5E2\"></td><td></td></tr>"+"\n";
		
		var RealTimeReport=tmpTab+RealTimeReportTAB+"</table>";
		document.getElementById("RealTimeReport").innerHTML=RealTimeReport;
	}
}

function realtimeitemstat(ReturnData){			//获取实时分量统计报告
	if(ReturnData.Return=="False"){
		document.getElementById("realtimeButton").src="image/button-realtime-reload-start.gif";//如果处于自动刷新状态则停止
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL==""){
			var boxURL="msg.htm?1.3";
			if(ReturnData.ErrorNo==90)boxURL="msg.htm?8.11";
		}
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		//alert(ReturnData.RealTimeReport);
		document.getElementById("StartTime").innerHTML=ReturnData.StartTime;
		document.getElementById("EndTime").innerHTML=ReturnData.EndTime;
		document.getElementById("HitCachesRate").innerHTML=ReturnData.HitCachesRate;
		document.getElementById("StatUrl").innerHTML=ReturnData.StatUrl;
		//var RealTimeReport=ReturnData.RealTimeReport.replace(new RegExp("\n","g"),"</td></tr><tr>")
		//RealTimeReport=RealTimeReport.replace(new RegExp(" ","gm"),"</td><td>")
		var RealTimeReport=ReturnData.RealTimeReport;
		RealTimeReport=RealTimeReport.split("\n");
		var RealTimeReportTAB="";
		for (var i=1;i<RealTimeReport.length-1;i++){
				var tmpChar=RealTimeReport[i];
				tmpChar=tmpChar.replace(new RegExp("\ +","g"),"|");
				tmpChar=tmpChar.replace(new RegExp("[A-Za-z0-9_|\|]?$","g"),"");
				tmpChar=tmpChar.replace("|","<td>");
				tmpChar=tmpChar.replace(new RegExp("[\|]","g"),"</td><td>");
				tmpChar=tmpChar+"</td>";
				
				tmpChar="<tr class=\"normal\" height=\"20\" onMouseOver=\"javascript:this.style.backgroundColor='#EFF5FB'\" onMouseOut=\"javascript:this.style.backgroundColor='#FFFFFF'\">"+"\n"+"	<td align=\"center\">"+i+"</td>" + tmpChar + "\n" + "</tr>"+"\n";
				tmpChar=tmpChar+"<tr><td width=\"100%\" colspan=\"4\" height=\"5\" background=\"image/line-5px.gif\"></td><td></td></tr>"+"\n";
				//if(i==1){alert(tmpChar)}
				RealTimeReportTAB=RealTimeReportTAB+tmpChar;
		}
		var tmpTab="<table width=\"660\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n";
		tmpTab=tmpTab+"	<tr class=\"pTitle\" height=\"25\">"+"\n";
		tmpTab=tmpTab+"		<td width=\"90\" align=\"center\">序号</td>"+"\n";
		tmpTab=tmpTab+"		<td width=\"190\">省份</td>"+"\n";
		tmpTab=tmpTab+"		<td width=\"190\">总请求量TR</td>"+"\n";
		tmpTab=tmpTab+"		<td width=\"190\">流量百分比%</td>"+"\n";
		tmpTab=tmpTab+"		<td></td>"+"\n";
		tmpTab=tmpTab+"	</tr>"+"\n";
		tmpTab=tmpTab+"	<tr><td height=\"1\" colspan=\"4\" bgcolor=\"#A7C5E2\"></td><td></td></tr>"+"\n";
		
		var RealTimeReport=tmpTab+RealTimeReportTAB+"</table>";
		document.getElementById("RealTimeReport").innerHTML=RealTimeReport;
	}	
}
//===========================================================================================================
//以下为系统配置部分
function systemlist(ReturnData){					//获取当前系统配置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?1.5";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		document.getElementById("MaxUsableMemSize").value=ReturnData.MaxUsableMemSize;
		document.getElementById("MaxConnections").value=ReturnData.MaxConnections;
		document.getElementById("MaxClientSendBuffer").value=ReturnData.MaxClientSendBuffer;
		document.getElementById("MaxClientRecvBuffer").value=ReturnData.MaxClientRecvBuffer;
		document.getElementById("MaxCacheBlockSize").value=ReturnData.MaxCacheBlockSize;
		document.getElementById("ClientRequstTimeOut").value=ReturnData.ClientRequstTimeOut;
		document.getElementById("PVRCreatingThisTime").value=ReturnData.PVRCreatingThisTime;
		document.getElementById("PVRCreatingPeriodTime").value=ReturnData.PVRCreatingPeriodTime;
		document.getElementById("MaxUpstreamConnections").value=ReturnData.MaxUpstreamConnections;
		document.getElementById("MaxSessionCacheSize").value=ReturnData.MaxSessionCacheSize;
		//alert(ReturnData.IsUsedMemCache);
		if(ReturnData.IsUsedMemCache=="1")document.getElementById("IsUsedMemCache").checked=true;
		if(ReturnData.IsUsedXForwordedFor=="1")document.getElementById("IsUsedXForwardedFor").checked=true;
		if(ReturnData.IsHitCacheForRefresh=="1")document.getElementById("IsHitCacheForRefresh").checked=true;
		if(ReturnData.IsUsedPageViewStat=="1")document.getElementById("IsUsedPageViewStat").checked=true;
		var PVRCreatingOptionOBJ=document.getElementsByName("PVRCreatingOption");
		for(var i=0;i<PVRCreatingOptionOBJ.length;i++){
			if(PVRCreatingOptionOBJ[i].value==ReturnData.PVRCreatingOption)	PVRCreatingOptionOBJ[i].checked=true;
		}
		//document.getElementById("PVRCreatingOption").value=ReturnData.PVRCreatingOption;(适用于select);
	}
}

function systemodi(ReturnData){					//修改当前系统配置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?1.6";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var boxURL="msg.htm?1.7";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}
	document.getElementById("systemodiButton").src="image/system-modi-button.gif";
}
//===========================================================================================================
//以下为主机管理部分及源站管理部分
function proxylist(ReturnData){					//获取当前主机列表
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?1.8";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var LISTHTML="";
		if(ReturnData.NumOfLists==0){
			LISTHTML="<tr><td width=\"100%\" height=\"300\" align=\"center\">当前未设置任何主机，请使用页面右下角的添加主机功能进行添加。</td></tr>"+"\n";
		}else{
			for(var i=0;i<ReturnData.NumOfLists;i++){
				if(ReturnData.Lists[i].Balance==0)Balance="轮询";		//源站负载均衡策略 轮询(0), IP地址哈希(1), URL地址哈希(2);
				if(ReturnData.Lists[i].Balance==1)Balance="IP地址哈希";
				if(ReturnData.Lists[i].Balance==2)Balance="URL地址哈希";

				LISTHTML=LISTHTML+"<tr ID=\"proxy"+ReturnData.Lists[i].ProxyID+"TR\"><td width=\"100%\">"+"\n";
				LISTHTML=LISTHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"  onMouseOver=\"javascript:this.style.backgroundColor='#EFF5FB'\" onMouseOut=\"javascript:if(document.getElementById('proxyupstream"+ReturnData.Lists[i].ProxyID+"TD').innerHTML=='')this.style.backgroundColor='#FFFFFF'\" style=\"cursor:pointer;\">"+"\n";
				
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"60\" ID=\"proxyIndexNO"+ReturnData.Lists[i].ProxyID+"TD\" rowspan=\"4\" align=\"center\" class=\"IDTD\">"+parseInt(i+1)+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"140\" class=\"objTitle\">主机名或IP地址：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"\" ID=\"proxyNAME"+ReturnData.Lists[i].ProxyID+"TD\" onclick=\"upstreamgetlist("+ReturnData.Lists[i].ProxyID+",0)\" class=\"underLine\">"+ReturnData.Lists[i].Host+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"100\" onclick=\"proxymodiBOX('"+ReturnData.Lists[i].ProxyID+"')\" class=\"underLine\" align=\"center\">"+"[修改配置]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">源站负载均衡策略：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"proxyBalance"+ReturnData.Lists[i].ProxyID+"TD\" onclick=\"upstreamgetlist("+ReturnData.Lists[i].ProxyID+",0)\" class=\"normal\">"+Balance+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td onclick=\"proxydelCONBOX('"+ReturnData.Lists[i].ProxyID+"')\" class=\"underLine\" align=\"center\">[删除配置]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\" onclick=\"upstreamgetlist("+ReturnData.Lists[i].ProxyID+",0)\">"+"备注说明："+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"proxyNote"+ReturnData.Lists[i].ProxyID+"TD\" onclick=\"upstreamgetlist("+ReturnData.Lists[i].ProxyID+",0)\" class=\"note\">"+ReturnData.Lists[i].Note+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td></td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";

				
				LISTHTML=LISTHTML+"	</table>"+"\n";
				LISTHTML=LISTHTML+"</td></tr>"+"\n";
				LISTHTML=LISTHTML+"<tr ID=\"proxyupstream"+ReturnData.Lists[i].ProxyID+"TR\" bgcolor=\"#FFFFFF\"><td ID=\"proxyupstream"+ReturnData.Lists[i].ProxyID+"TD\">"+"</td></tr>"+"\n";
				LISTHTML=LISTHTML+"<tr ID=\"proxy"+ReturnData.Lists[i].ProxyID+"lineTR\"><td width=\"100%\" height=\"5\" background=\"image/line-5px.gif\"></td></tr>"+"\n";

			}
		}
		LISTHTML="<table ID=\"proxyTAB\" width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n"+LISTHTML+"\n"+"<PROXYLISTEND></table>"+"\n";
		document.getElementById("HOSTLIST").innerHTML=LISTHTML;
		//alert(LISTHTML);
	}
}




function proxyadd(ReturnData){					//添加主机
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL==""){
			var boxURL="msg.htm?2.3";
			if(ReturnData.ErrorNo==50)boxURL="msg.htm?2.31";
		}
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		//============================================================
		//重新获取值，添加进当前列表
		var Host=document.getElementById("Host").value;
		var BalanceOBJ=document.getElementsByName("Balance");
		for(i=0;i<BalanceOBJ.length;i++){
			if(BalanceOBJ[i].checked==true)var Balance=BalanceOBJ[i].value;
		}

		if(Balance==0)Balance="轮询";			//源站负载均衡策略 轮询(0), IP地址哈希(1), URL地址哈希(2);
		if(Balance==1)Balance="IP地址哈希";
		if(Balance==2)Balance="URL地址哈希";
		var Note=document.getElementById("Note").value;
		//对新添加主机HTML代码进行拼接
		//============================================================
		var ADDHTML="";
		var tabROWS=parent.document.getElementById("proxyTAB").rows.length;
		//alert(tabROWS);
		if(tabROWS<3){
			addROWID=1;
		}else{
			addROWID=parseInt(tabROWS/3)+1;
		}

				ADDHTML=ADDHTML+"<tr ID=\"proxy"+ReturnData.ProxyID+"TR\"><td width=\"100%\">"+"\n";
				ADDHTML=ADDHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"  onMouseOver=\"javascript:this.style.backgroundColor='#EFF5FB'\" onMouseOut=\"javascript:if(document.getElementById('proxyupstream"+ReturnData.ProxyID+"TD').innerHTML=='')this.style.backgroundColor='#FFFFFF'\" style=\"cursor:pointer;\">"+"\n";


				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td width=\"60\" ID=\"proxyIndexNO"+ReturnData.ProxyID+"TD\" rowspan=\"4\" align=\"center\" class=\"IDTD\">"+addROWID+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td width=\"140\" class=\"objTitle\">主机名或 IP 地址：</td>"+"\n";
				ADDHTML=ADDHTML+"			<td width=\"\" ID=\"proxyNAME"+ReturnData.ProxyID+"TD\" onclick=\"upstreamgetlist("+ReturnData.ProxyID+",0)\" class=\"underLine\">"+Host+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td width=\"90\" onclick=\"proxymodiBOX('"+ReturnData.ProxyID+"')\" class=\"underLine\" align=\"center\">"+"[修改配置]</td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";
				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td class=\"objTitle\">源站负载均衡策略：</td>"+"\n";
				ADDHTML=ADDHTML+"			<td ID=\"proxyBalance"+ReturnData.ProxyID+"TD\" onclick=\"upstreamgetlist("+ReturnData.ProxyID+",0)\" class=\"normal\">"+Balance+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td onclick=\"proxydelCONBOX('"+ReturnData.ProxyID+"')\" class=\"underLine\" align=\"center\">[删除配置]</td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";
				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td class=\"objTitle\" onclick=\"upstreamgetlist("+ReturnData.ProxyID+",0)\">"+"备注说明："+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td ID=\"proxyNote"+ReturnData.ProxyID+"TD\" onclick=\"upstreamgetlist("+ReturnData.ProxyID+",0)\" class=\"note\">"+Note+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td></td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";
			
				ADDHTML=ADDHTML+"	</table>"+"\n";
				ADDHTML=ADDHTML+"</td></tr>"+"\n";
				ADDHTML=ADDHTML+"<tr ID=\"proxyupstream"+ReturnData.ProxyID+"TR\" bgcolor=\"#FFFFFF\"><td ID=\"proxyupstream"+ReturnData.ProxyID+"TD\"></td></tr>"+"\n";
				ADDHTML=ADDHTML+"<tr ID=\"proxy"+ReturnData.ProxyID+"lineTR\"><td width=\"100%\" height=\"5\" background=\"image/line-5px.gif\"></td></tr>"+"\n";

		//alert(ADDHTML);
		//============================================================
		//获取当前内容，将新加内容进行拼接，写回
		
		var nowHTML=parent.document.getElementById("HOSTLIST").innerHTML;
		if(nowHTML.indexOf("未设置任何主机")!=-1){
			var LISTHTML="<table ID=\"proxyTAB\" width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n"+ADDHTML+"\n"+"<PROXYLISTEND></table>"+"\n";
		}else{
			if(Sys.ie){
				var SPLITCHAR="<PROXYLISTEND>";
			}else{
				var SPLITCHAR="<proxylistend>";
			}
			//alert(nowHTML);
			nowHTML=nowHTML.split(SPLITCHAR)[0];
			var LISTHTML=nowHTML+"\n"+ADDHTML+"\n"+"<PROXYLISTEND>"+"\n"+"</table>";
		}
		//alert(LISTHTML);
		parent.document.getElementById("HOSTLIST").innerHTML=LISTHTML;
		//============================================================		
		//parent.location.reload();
		//alert(parent.host.document.getElementById("HOSTLIST").innerHTML)
		
		var boxURL="msg.htm?2.4";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		parent.document.documentElement.scrollTop=parent.document.documentElement.scrollHeight;
	}
	document.getElementById("proxyADDbutton").src="image/host-add-button.gif";	//修改BUTTON
}


function proxydel(ReturnData){					//删除主机
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?2.1";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var strTAB=document.getElementById("proxyTAB");
		var strTR1=document.getElementById("proxy"+ReturnData.ProxyID+"TR").rowIndex;
		var strTR2=document.getElementById("proxyupstream"+ReturnData.ProxyID+"TR").rowIndex;
		var strTR3=document.getElementById("proxy"+ReturnData.ProxyID+"lineTR").rowIndex;
		strTAB.deleteRow(strTR3);
		strTAB.deleteRow(strTR2);
		strTAB.deleteRow(strTR1);

		resetIndexNO('proxy','0',3);			//重新排序
		var boxURL="msg.htm?2.2";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}
}


function proxyviewset(ReturnData){				//获取主机配置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?2.5";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		if(ReturnData.NumOfLists==0){
			var boxURL="msg.htm?2.6";
			showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		}else{
			var Balance=ReturnData.Lists[0].Balance;
			var BalanceOBJ=document.getElementsByName("Balance");
			for(i=0;i<BalanceOBJ.length;i++){
				if(BalanceOBJ[i].value==Balance)BalanceOBJ[i].checked=true;
			}
			document.getElementById("Host").value=ReturnData.Lists[0].Host;
			document.getElementById("Note").innerHTML=ReturnData.Lists[0].Note;	
		}
	}
}

function proxymodi(ReturnData){				//修改主机配置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL==""){
			var boxURL="msg.htm?2.7";
			if(ReturnData.ErrorNo==51)boxURL="msg.htm?2.71";
		}
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var boxURL="msg.htm?2.8";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		//============================================
		//修改列表中内容
		var ProxyID=ReturnData.ProxyID;
		var Host=document.getElementById("Host").value;
		var BalanceOBJ=document.getElementsByName("Balance");
		for(i=0;i<BalanceOBJ.length;i++){
			if(BalanceOBJ[i].checked==true)var Balance=BalanceOBJ[i].value;
		}
		var Note=document.getElementById("Note").value;
		if(Balance==0)Balance="轮询";
		if(Balance==1)Balance="IP地址哈希";
		if(Balance==2)Balance="URL地址哈希";
		
		parent.document.getElementById("proxyNAME"+ProxyID+"TD").innerHTML=Host;
		parent.document.getElementById("proxyBalance"+ProxyID+"TD").innerHTML=Balance;
		parent.document.getElementById("proxyNote"+ProxyID+"TD").innerHTML=Note;
	}
	document.getElementById("proxyMODIbutton").src="image/host-modi-button.gif";
}


function upstreamlist(ReturnData,ProxyID){		//获取源站列表
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?1.9";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		//TABTMPLATE为源站的框架TABLE
		//LISTHTML为源站TABLE
		var LISTHTML="";
		var TABTMPLATE="";
		var strproxyIndexNOTD="proxyIndexNO"+ProxyID+"TD";
		var strproxyIndexNO=document.getElementById(strproxyIndexNOTD).innerHTML;
		if(Sys.ie){
			var TDTMPHEIGHT="32px";
		}else{
			var TDTMPHEIGHT="42px";
		}
		//===================================================
		//框架TABLE头部
		TABTMPLATE=TABTMPLATE+"<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n";
		TABTMPLATE=TABTMPLATE+"	<tr>"+"\n";
		TABTMPLATE=TABTMPLATE+"		<td style=\"background:url(image/childtab-top-left.gif);width:330px;height:"+TDTMPHEIGHT+";overflow:hidden;padding-top:10px;font-weight:bold;font-size:12px\">　当前序号为　<span style=\"color:#1875C6\">"+strproxyIndexNO+"</span>　的主机，其源站设置如下</td>"+"\n";
		TABTMPLATE=TABTMPLATE+"		<td style=\"background:url(image/childtab-top-middle.gif);\">&nbsp;</td>"+"\n";
		TABTMPLATE=TABTMPLATE+"		<td style=\"background:url(image/childtab-top-right.gif);width:20px;\"></td>"+"\n";
		TABTMPLATE=TABTMPLATE+"	</tr>"+"\n";
		TABTMPLATE=TABTMPLATE+"</table>"+"\n";
		TABTMPLATE=TABTMPLATE+"<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n";
		TABTMPLATE=TABTMPLATE+"	<tr>"+"\n";
		TABTMPLATE=TABTMPLATE+"		<td style=\"background:url(image/childtab-middle-left.gif);width:7px;\"></td>"+"\n";
		TABTMPLATE=TABTMPLATE+"		<td bgcolor=\"#FFFFFF\">"+"\n";
		//===================================================
		if(ReturnData.NumOfLists==0){
			//提示此主机当前无任何源站
			LISTHTML=LISTHTML+"				<tr><td bgcolor=\"#FFFFFF\" width=\"100%\" height=\"80\" colspan=\"5\" align=\"center\">此主机暂未设置任何源站</td></tr>"+"\n";
		}else{
			for(var i=0;i<ReturnData.NumOfLists;i++){
				
				
				LISTHTML=LISTHTML+"<tr><td>"	
				
				LISTHTML=LISTHTML+"	<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"  onMouseOver=\"javascript:this.style.backgroundColor='#EFF5FB'\" onMouseOut=\"javascript:this.style.backgroundColor='#FFFFFF'\" style=\"cursor:pointer;\">"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"60\" ID=\"proxy"+ProxyID+"upstream"+ReturnData.Lists[i].UpstreamID+"IDTD\" rowspan=\"2\" align=\"center\" class=\"IDTD\">"+parseInt(i+1)+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"100\" class=\"objTitle\">源站名或IP：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"\"  ID=\"proxy"+ProxyID+"upstream"+ReturnData.Lists[i].UpstreamID+"HostTD\" class=\"underLine\">"+ReturnData.Lists[i].Host+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"100\" onclick=\"upstreamodiBOX('"+ProxyID+"','"+ReturnData.Lists[i].UpstreamID+"')\"  class=\"underLine\" align=\"center\">"+"[修改配置]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">"+"备注说明："+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"upstreamNote"+ReturnData.Lists[i].PermitID+"TD\" class=\"note\">"+ReturnData.Lists[i].Note+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td onclick=\"upstreamdelCONBOX('"+ProxyID+"','"+ReturnData.Lists[i].UpstreamID+"')\" class=\"underLine\" align=\"center\" style=\"border-bottom:0px dashed #ccc;\">[删除配置]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";

				LISTHTML=LISTHTML+"	</table>"+"\n";
				LISTHTML=LISTHTML+"<tr><td width=\"100%\" colspan=\"4\" height=\"5\" background=\"image/line-5px.gif\"></td></tr>"+"\n";
				LISTHTML=LISTHTML+"</td></tr>"+"\n";
			}
		}
		//alert(LISTHTML);
		//增加源站的说明及操作
		//LISTHTML="<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+LISTHTML+"</table>"
		LISTHTML="			<table width=\"95%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">"+"\n"+"				<tr style=\"font-size:12px;color:#1875C6;\"><td height=\"25\" style=\"padding-left:18px;\">序号</td><tr><td height=\"1\" bgcolor=\"#A7C5E2\">"+"\n"+LISTHTML+"\n";
		LISTHTML=LISTHTML+"				<tr><td height=\"35\" align=\"right\" valign=\"bottom\" style=\"padding-right:8px;\"><img src=\"image/button-upstream-add.gif\" onclick=\"upstreamaddBOX('"+ProxyID+"');\" style=\"cursor:pointer;\"> <img src=\"image/button-reload.gif\" onclick=\"upstreamgetlist('"+ProxyID+"',1)\" style=\"cursor:pointer;\"></td></tr>"+"\n";
		LISTHTML=LISTHTML+"			</table>"+"\n";
		//将源站表格嵌入框架中
		TABTMPLATE=TABTMPLATE+"\n"+LISTHTML+"\n";
		//===================================================
		//框架TABLE尾部
		TABTMPLATE=TABTMPLATE+"		</td>"+"\n";
		TABTMPLATE=TABTMPLATE+"		<td style=\"background:url(image/childtab-middle-right.gif);width:7px;\"></td>"+"\n";
		TABTMPLATE=TABTMPLATE+"	</tr>"+"\n";
		TABTMPLATE=TABTMPLATE+"</table>"+"\n";
		TABTMPLATE=TABTMPLATE+"<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n";
		TABTMPLATE=TABTMPLATE+"	<tr>"+"\n";
		TABTMPLATE=TABTMPLATE+"		<td style=\"background:url(image/childtab-bottom-left.gif);width:14px;height:16px;\"></td>"+"\n";
		TABTMPLATE=TABTMPLATE+"		<td style=\"background:url(image/childtab-bottom-middle.gif);\">&nbsp;</td>"+"\n";
		TABTMPLATE=TABTMPLATE+"		<td style=\"background:url(image/childtab-bottom-right.gif);width:14px;\"></td>"+"\n";
		TABTMPLATE=TABTMPLATE+"	</tr>"+"\n";
		TABTMPLATE=TABTMPLATE+"</table>"+"\n";
		//===================================================
		var strTD="proxyupstream"+ProxyID+"TD";
		document.getElementById(strTD).innerHTML=TABTMPLATE;
		//alert(LISTHTML);
	}
}

function upstreamadd(ReturnData){						//添加源站
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL==""){
			var boxURL="msg.htm?2.9";
			if(ReturnData.ErrorNo==52)boxURL="msg.htm?2.91";
		}
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var boxURL="msg.htm?3.0";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		parent.upstreamgetlist(ReturnData.ProxyID,1);
	}
	document.getElementById("upstreamADDbutton").src="image/upstream-add-button.gif";
}

function upstreamdel(ReturnData){						//删除源站
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?3.2";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var boxURL="msg.htm?3.3";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		upstreamgetlist(ReturnData.ProxyID,1);
	}
}

function upstreamviewset(ReturnData){					//获取源站配置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?3.4";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		if(ReturnData.NumOfLists==0){
			var boxURL="msg.htm?3.5";
			showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		}else{
			document.getElementById("Host").value=ReturnData.Lists[0].Host;
			document.getElementById("Note").innerHTML=ReturnData.Lists[0].Note;	
		}
	}
}

function upstreamodi(ReturnData){						//修改源站配置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL==""){
			var boxURL="msg.htm?3.6";
			if(ReturnData.ErrorNo==53)boxURL="msg.htm?3.61";
		}
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var boxURL="msg.htm?3.7";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		//============================================
		//修改列表中内容
		parent.upstreamgetlist(ReturnData.ProxyID,1);	//刷新
	}
	document.getElementById("upstreamMODIbutton").src="image/upstream-modi-button.gif";
}

//===========================================================================================================
//以下为防盗链管理部分
function protectlist(ReturnData){						//获取当前保护链列表
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?3.8";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var LISTHTML="";
		if(ReturnData.NumOfLists==0){
			LISTHTML="<tr><td width=\"100%\" height=\"300\" align=\"center\">当前未设置任何保护链，请使用页面右下角的添加保护链功能进行添加。</td></tr>";
		}else{
			for(var i=0;i<ReturnData.NumOfLists;i++){
				if(ReturnData.Lists[i].Icase==0)var Icase="不忽略";		//保护链设置是否忽略大小写，0：不忽略；1：忽略;
				if(ReturnData.Lists[i].Icase==1)var Icase="忽略";
				
				LISTHTML=LISTHTML+"<tr ID=\"protect"+ReturnData.Lists[i].ProtectID+"TR\"><td width=\"100%\">"+"\n";
				LISTHTML=LISTHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"  onMouseOver=\"javascript:this.style.backgroundColor='#EFF5FB'\" onMouseOut=\"javascript:if(document.getElementById('protectpermit"+ReturnData.Lists[i].ProtectID+"TD').innerHTML=='')this.style.backgroundColor='#FFFFFF'\" style=\"cursor:pointer;\">"+"\n";
				
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"60\" ID=\"protectIndexNO"+ReturnData.Lists[i].ProtectID+"TD\" rowspan=\"4\" align=\"center\" class=\"IDTD\">"+parseInt(i+1)+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"140\" class=\"objTitle\">保护链地址URL：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"\" ID=\"protectURL"+ReturnData.Lists[i].ProtectID+"TD\" onclick=\"permitgetlist("+ReturnData.Lists[i].ProtectID+",0)\" class=\"underLine\">"+ReturnData.Lists[i].ProtectUrl+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"100\" onclick=\"protectmodiBOX('"+ReturnData.Lists[i].ProtectID+"')\" class=\"underLine\" align=\"center\">"+"[修改配置]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">盗链时转向URL：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"protectLURL"+ReturnData.Lists[i].ProtectID+"TD\" onclick=\"permitgetlist("+ReturnData.Lists[i].ProtectID+",0)\" class=\"underLine\">"+ReturnData.Lists[i].LocationUrl+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td onclick=\"protectdelCONBOX('"+ReturnData.Lists[i].ProtectID+"')\" class=\"underLine\" align=\"center\">[删除配置]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">是否忽略大小写：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"protectIcase"+ReturnData.Lists[i].ProtectID+"TD\" onclick=\"permitgetlist("+ReturnData.Lists[i].ProtectID+",0)\" class=\"normal\">"+Icase+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td></td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\" onclick=\"permitgetlist("+ReturnData.Lists[i].ProtectID+",0)\">"+"备注说明："+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"protectNote"+ReturnData.Lists[i].ProtectID+"TD\" onclick=\"permitgetlist("+ReturnData.Lists[i].ProtectID+",0)\" class=\"note\">"+ReturnData.Lists[i].Note+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td></td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				
				LISTHTML=LISTHTML+"	</table>"+"\n";
				LISTHTML=LISTHTML+"</td></tr>"+"\n";
				LISTHTML=LISTHTML+"<tr ID=\"protectpermit"+ReturnData.Lists[i].ProtectID+"TR\" bgcolor=\"#FFFFFF\"><td ID=\"protectpermit"+ReturnData.Lists[i].ProtectID+"TD\"></td></tr>"+"\n";
				LISTHTML=LISTHTML+"<tr ID=\"protect"+ReturnData.Lists[i].ProtectID+"lineTR\"><td width=\"100%\" height=\"5\" background=\"image/line-5px.gif\"></td></tr>"+"\n";

			}
		}
		LISTHTML="<table ID=\"protectTAB\" width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n"+LISTHTML+"\n"+"<PROTECTLISTEND></table>"+"\n";
		document.getElementById("PROTECTLIST").innerHTML=LISTHTML;
		//alert(LISTHTML);
	}
}


function protectadd(ReturnData){					//添加保护链
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL==""){
			var boxURL="msg.htm?3.9";
			if(ReturnData.ErrorNo==70)boxURL="msg.htm?3.91";
		}
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		//============================================================
		//重新获取值，添加进当前列表
		var ProtectUrl=document.getElementById("ProtectUrl").value;
		var LocationUrl=document.getElementById("LocationUrl").value;
		var IcaseOBJ=document.getElementsByName("Icase");
		for(i=0;i<IcaseOBJ.length;i++){
			if(IcaseOBJ[i].checked==true)var Icase=IcaseOBJ[i].value;
		}

		if(Icase==0)Icase="不忽略";					//保护链设置是否忽略大小写，0：不忽略；1：忽略;;
		if(Icase==1)Icase="忽略";
		var Note=document.getElementById("Note").value;
		//对新添加保护链HTML代码进行拼接
		//============================================================
		var ADDHTML="";
		var tabROWS=parent.document.getElementById("protectTAB").rows.length;
		//alert(tabROWS);
		if(tabROWS<3){
			addROWID=1;
		}else{
			addROWID=parseInt(tabROWS/3)+1;
		}

				ADDHTML=ADDHTML+"<tr ID=\"protect"+ReturnData.ProtectID+"TR\"><td width=\"100%%\">"+"\n";
				ADDHTML=ADDHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"  onMouseOver=\"javascript:this.style.backgroundColor='#EFF5FB'\" onMouseOut=\"javascript:if(document.getElementById('protectpermit"+ReturnData.ProtectID+"TD').innerHTML=='')this.style.backgroundColor='#FFFFFF'\" style=\"cursor:pointer;\">"+"\n";
				
				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td width=\"60\" ID=\"protectIndexNO"+ReturnData.ProtectID+"TD\" rowspan=\"4\" align=\"center\" class=\"IDTD\">"+addROWID+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td width=\"140\" class=\"objTitle\">保护链地址URL：</td>"+"\n";
				ADDHTML=ADDHTML+"			<td width=\"\" ID=\"protectURL"+ReturnData.ProtectID+"TD\" onclick=\"permitgetlist("+ReturnData.ProtectID+",0)\" class=\"underLine\">"+ProtectUrl+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td width=\"90\" onclick=\"protectmodiBOX('"+ReturnData.ProtectID+"')\" class=\"underLine\" align=\"center\">"+"[修改配置]</td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";
				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td class=\"objTitle\">盗链时转向URL：</td>"+"\n";
				ADDHTML=ADDHTML+"			<td ID=\"protectLURL"+ReturnData.ProtectID+"TD\" onclick=\"permitgetlist("+ReturnData.ProtectID+",0)\" class=\"underLine\">"+LocationUrl+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td onclick=\"protectdelCONBOX('"+ReturnData.ProtectID+"')\"  class=\"underLine\" align=\"center\">[删除配置]</td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";
				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td class=\"objTitle\">是否忽略大小写：</td>"+"\n";
				ADDHTML=ADDHTML+"			<td ID=\"protectIcase"+ReturnData.ProtectID+"TD\" onclick=\"permitgetlist("+ReturnData.ProtectID+",0)\" class=\"normal\">"+Icase+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td></td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";
				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td class=\"objTitle\" onclick=\"permitgetlist("+ReturnData.ProtectID+",0)\">"+"备注说明："+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td ID=\"protectNote"+ReturnData.ProtectID+"TD\" onclick=\"permitgetlist("+ReturnData.ProtectID+",0)\" class=\"note\">"+Note+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td></td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";
				
				ADDHTML=ADDHTML+"	</table>"+"\n";
				ADDHTML=ADDHTML+"</td></tr>"+"\n";
				ADDHTML=ADDHTML+"<tr ID=\"protectpermit"+ReturnData.ProtectID+"TR\" bgcolor=\"#FFFFFF\"><td ID=\"protectpermit"+ReturnData.ProtectID+"TD\"></td></tr>"+"\n";
				ADDHTML=ADDHTML+"<tr ID=\"protect"+ReturnData.ProtectID+"lineTR\"><td width=\"100%\" height=\"5\" background=\"image/line-5px.gif\"></td></tr>"+"\n";

		//alert(ADDHTML);
		//============================================================
		//获取当前内容，将新加内容进行拼接，写回
		
		var nowHTML=parent.document.getElementById("PROTECTLIST").innerHTML;
		if(nowHTML.indexOf("未设置任何保护链")!=-1){
			var LISTHTML="<table ID=\"protectTAB\" width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n"+ADDHTML+"\n"+"<PROTECTLISTEND></table>";
		}else{
			if(Sys.ie){
				var SPLITCHAR="<PROTECTLISTEND>";
			}else{
				var SPLITCHAR="<protectlistend>";
			}
			//alert(nowHTML);
			nowHTML=nowHTML.split(SPLITCHAR)[0];
			var LISTHTML=nowHTML+ADDHTML+"<PROTECTLISTEND></table>";
		}
		//alert(LISTHTML);
		parent.document.getElementById("PROTECTLIST").innerHTML=LISTHTML;
		//============================================================		
		//parent.location.reload();
		//alert(parent.host.document.getElementById("HOSTLIST").innerHTML)
		
		var boxURL="msg.htm?4.0";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		parent.document.documentElement.scrollTop=parent.document.documentElement.scrollHeight;
	}
	document.getElementById("protectADDbutton").src="image/protect-add-button.gif";	//修改BUTTON
}

function protectviewset(ReturnData){			//获取保护链配置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?4.1";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		if(ReturnData.NumOfLists==0){
			var boxURL="msg.htm?4.2";
			showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		}else{
			var ProtectID=ReturnData.Lists[0].ProtectID;
			document.getElementById("ProtectUrl").value=ReturnData.Lists[0].ProtectUrl;
			document.getElementById("LocationUrl").value=ReturnData.Lists[0].LocationUrl;
			document.getElementById("Note").value=ReturnData.Lists[0].Note;
			var Icase=ReturnData.Lists[0].Icase;
			var IcaseOBJ=document.getElementsByName("Icase");
			for(i=0;i<IcaseOBJ.length;i++){
				if(IcaseOBJ[i].value==Icase)IcaseOBJ[i].checked=true;
			}
		}
	}
}
function protectmodi(ReturnData){				//修改保护链配置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL==""){
			var boxURL="msg.htm?4.3";
			if(ReturnData.ErrorNo==71)boxURL="msg.htm?4.31";
		}
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var boxURL="msg.htm?4.4";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		//============================================
		//修改列表中内容
		var ProtectID=ReturnData.ProtectID;
		var ProtectUrl=document.getElementById("ProtectUrl").value;
		var LocationUrl=document.getElementById("LocationUrl").value;
		var Note=document.getElementById("Note").value;
		var IcaseOBJ=document.getElementsByName("Icase");
		for(i=0;i<IcaseOBJ.length;i++){
			if(IcaseOBJ[i].checked==true)var Icase=IcaseOBJ[i].value;
		}

		if(Icase==0)Icase="不忽略";
		if(Icase==1)Icase="忽略";
		
		parent.document.getElementById("protectURL"+ProtectID+"TD").innerHTML=ProtectUrl;
		parent.document.getElementById("protectLURL"+ProtectID+"TD").innerHTML=LocationUrl;
		parent.document.getElementById("protectIcase"+ProtectID+"TD").innerHTML=Icase;
		parent.document.getElementById("protectNote"+ProtectID+"TD").innerHTML=Note;
	}
	document.getElementById("protectMODIbutton").src="image/protect-modi-button.gif";
}

function protectdel(ReturnData){				//删除保护链
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?4.6";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var strTAB=document.getElementById("protectTAB");
		var strTR1=document.getElementById("protect"+ReturnData.ProtectID+"TR").rowIndex;
		var strTR2=document.getElementById("protectpermit"+ReturnData.ProtectID+"TR").rowIndex;
		var strTR3=document.getElementById("protect"+ReturnData.ProtectID+"lineTR").rowIndex;

		strTAB.deleteRow(strTR3);
		strTAB.deleteRow(strTR2);
		strTAB.deleteRow(strTR1);
		
		resetIndexNO('protect','0',3);	//重新排序
		
		var boxURL="msg.htm?4.7";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}
}
//ProtectID - 保护链标识号 ID;
//PermitID - 引用链标识号 ID;
function permitlist(ReturnData,ProtectID){		//获取引用链列表
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?4.8";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		//TABTMPLATE为引用链的框架TABLE
		//LISTHTML为引用链TABLE
		var LISTHTML="";
		var TABTMPLATE="";

		var strprotectIndexNOTD="protectIndexNO"+ProtectID+"TD";
		var strprotectIndexNO=document.getElementById(strprotectIndexNOTD).innerHTML;
		if(Sys.ie){
			var TDTMPHEIGHT="32px";
		}else{
			var TDTMPHEIGHT="42px";
		}
		//===================================================
		//框架TABLE头部
		TABTMPLATE=TABTMPLATE+"<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n";
		TABTMPLATE=TABTMPLATE+"	<tr>"+"\n";
		TABTMPLATE=TABTMPLATE+"		<td style=\"background:url(image/childtab-top-left.gif);width:330px;height:"+TDTMPHEIGHT+";overflow:hidden;padding-top:10px;font-weight:bold;font-size:12px\">　　当前序号为　<span style=\"color:#1875C6\">"+strprotectIndexNO+"</span>　的保护链，其引用链设置如下</td>"+"\n";
		TABTMPLATE=TABTMPLATE+"		<td style=\"background:url(image/childtab-top-middle.gif);\">&nbsp;</td>"+"\n";
		TABTMPLATE=TABTMPLATE+"		<td style=\"background:url(image/childtab-top-right.gif);width:20px;\"></td>"+"\n";
		TABTMPLATE=TABTMPLATE+"	</tr>"+"\n";
		TABTMPLATE=TABTMPLATE+"</table>"+"\n";
		TABTMPLATE=TABTMPLATE+"<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n";
		TABTMPLATE=TABTMPLATE+"	<tr>"+"\n";
		TABTMPLATE=TABTMPLATE+"		<td style=\"background:url(image/childtab-middle-left.gif);width:7px;\"></td>"+"\n";
		TABTMPLATE=TABTMPLATE+"		<td bgcolor=\"#FFFFFF\">"+"\n";

		//===================================================
		if(ReturnData.NumOfLists==0){
			//提示此引用链当前无任何引用链
			LISTHTML=LISTHTML+"				<tr><td bgcolor=\"#FFFFFF\" width=\"100%\" height=\"66\" colspan=\"6\" align=\"center\">此保护链暂未设置任何引用链</td></tr>"+"\n";
		}else{
			for(var i=0;i<ReturnData.NumOfLists;i++){
				var Icase=ReturnData.Lists[i].Icase;	//引用链设置是否忽略大小写，0：不忽略；1：忽略;;
				if(Icase==0)Icase="不忽略";					
				if(Icase==1)Icase="忽略";
				
				LISTHTML=LISTHTML+"<tr><td>"	
				LISTHTML=LISTHTML+"	<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"  onMouseOver=\"javascript:this.style.backgroundColor='#EFF5FB'\" onMouseOut=\"javascript:this.style.backgroundColor='#FFFFFF'\" style=\"cursor:pointer;\">"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"60\" ID=\"protect"+ProtectID+"permit"+ReturnData.Lists[i].PermitID+"IDTD\" rowspan=\"3\" align=\"center\" class=\"IDTD\">"+parseInt(i+1)+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"140\" class=\"objTitle\">引用链地址URL：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"\" ID=\"protect"+ProtectID+"permit"+ReturnData.Lists[i].PermitID+"TD\" class=\"underLine\">"+ReturnData.Lists[i].PermitUrl+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"100\" onclick=\"permitmodiBOX('"+ProtectID+"','"+ReturnData.Lists[i].PermitID+"')\" class=\"underLine\" align=\"center\">"+"[修改配置]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">是否忽略大小写：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"permitIcase"+ReturnData.Lists[i].PermitID+"TD\" class=\"normal\">"+Icase+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td onclick=\"permitdelCONBOX('"+ProtectID+"','"+ReturnData.Lists[i].PermitID+"')\" class=\"underLine\" align=\"center\" style=\"border-bottom:0px dashed #ccc;\">[删除配置]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">"+"备注说明："+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"permitNote"+ReturnData.Lists[i].PermitID+"TD\" class=\"note\">"+ReturnData.Lists[i].Note+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td></td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";

				LISTHTML=LISTHTML+"	</table>"+"\n";
				LISTHTML=LISTHTML+"</td></tr>"+"\n";
				LISTHTML=LISTHTML+"<tr><td width=\"100%\" colspan=\"4\" height=\"5\" background=\"image/line-5px.gif\"></td></tr>"+"\n";
			}
		}
		//alert(LISTHTML);
		//增加引用链的说明及操作
		//LISTHTML="<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+LISTHTML+"</table>"
		LISTHTML="			<table width=\"95%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">"+"\n"+"				<tr  style=\"font-size:12px;color:#1875C6;\"><td height=\"25\" style=\"padding-left:18px;\">序号</td><tr><td height=\"1\" bgcolor=\"#A7C5E2\">"+"\n"+LISTHTML+"\n";
		LISTHTML=LISTHTML+"				<tr><td height=\"35\" align=\"right\" valign=\"bottom\" style=\"padding-right:8px;\"><img src=\"image/button-permit-add.gif\" onclick=\"permitaddBOX('"+ProtectID+"');\" style=\"cursor:pointer;\"> <img src=\"image/button-reload.gif\" onclick=\"permitgetlist('"+ProtectID+"',1)\" style=\"cursor:pointer;\"></td></tr>"+"\n";
		LISTHTML=LISTHTML+"			</table>"+"\n";
		//将源站表格嵌入框架中
		TABTMPLATE=TABTMPLATE+"\n"+LISTHTML+"\n";
		//===================================================
		//框架TABLE尾部
		TABTMPLATE=TABTMPLATE+"		</td>"+"\n";
		TABTMPLATE=TABTMPLATE+"		<td style=\"background:url(image/childtab-middle-right.gif);width:7px;\"></td>"+"\n";
		TABTMPLATE=TABTMPLATE+"	</tr>"+"\n";
		TABTMPLATE=TABTMPLATE+"</table>"+"\n";
		TABTMPLATE=TABTMPLATE+"<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n";
		TABTMPLATE=TABTMPLATE+"	<tr>"+"\n";
		TABTMPLATE=TABTMPLATE+"		<td style=\"background:url(image/childtab-bottom-left.gif);width:14px;height:16px;\"></td>"+"\n";
		TABTMPLATE=TABTMPLATE+"		<td style=\"background:url(image/childtab-bottom-middle.gif);\">&nbsp;</td>"+"\n";
		TABTMPLATE=TABTMPLATE+"		<td style=\"background:url(image/childtab-bottom-right.gif);width:14px;\"></td>"+"\n";
		TABTMPLATE=TABTMPLATE+"	</tr>"+"\n";
		TABTMPLATE=TABTMPLATE+"</table>"+"\n";

		//===================================================
		var strTD="protectpermit"+ProtectID+"TD";
		document.getElementById(strTD).innerHTML=TABTMPLATE;
		//alert(LISTHTML);
	}
}

function permitadd(ReturnData){				//添加引用链
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL==""){
			var boxURL="msg.htm?4.9";
			if(ReturnData.ErrorNo==72)boxURL="msg.htm?4.91";
		}
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var boxURL="msg.htm?5.0";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		parent.permitgetlist(ReturnData.ProtectID,1);
	}
	document.getElementById("permitADDbutton").src="image/permit-add-button.gif";
}

function permitviewset(ReturnData){			//获取引用链配置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?5.1";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		if(ReturnData.NumOfLists==0){
			var boxURL="msg.htm?5.2";
			showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		}else{
			var Icase=ReturnData.Lists[0].Icase;
			var IcaseOBJ=document.getElementsByName("Icase");
			for(var i=0;i<IcaseOBJ.length;i++){
				if(IcaseOBJ[i].value==Icase)IcaseOBJ[i].checked=true;
			}
			document.getElementById("PermitUrl").value=ReturnData.Lists[0].PermitUrl;
			document.getElementById("Note").innerHTML=ReturnData.Lists[0].Note;	
		}
	}
}

function permitmodi(ReturnData){				//修改引用链配置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL==""){
			var boxURL="msg.htm?5.3";
			if(ReturnData.ErrorNo==73)boxURL="msg.htm?5.31";
		}
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var boxURL="msg.htm?3.7";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		//============================================
		//修改列表中内容
		parent.permitgetlist(ReturnData.ProtectID,1);//刷新
	}
	document.getElementById("permitMODIbutton").src="image/permit-modi-button.gif";
}

function permitdel(ReturnData){					//删除引用链
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?5.6";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var boxURL="msg.htm?5.7";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		permitgetlist(ReturnData.ProtectID,1);
	}
}


//===========================================================================================================
//以下为黑名单管理部分
function blacklist(ReturnData){					//获取当前黑名单列表
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?5.8";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var LISTHTML="";
		if(ReturnData.NumOfLists==0){
			LISTHTML="<tr><td width=\"100%\" height=\"300\" align=\"center\">当前未设置任何黑名单，请使用页面右下角的添加黑名单功能进行添加。</td></tr>";
		}else{
			for(var i=0;i<ReturnData.NumOfLists;i++){
				
				LISTHTML=LISTHTML+"<tr ID=\"black"+ReturnData.Lists[i].BlackID+"TR\"><td width=\"100%\">"+"\n";
				
				LISTHTML=LISTHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"  onMouseOver=\"javascript:this.style.backgroundColor='#EFF5FB'\" onMouseOut=\"javascript:this.style.backgroundColor='#FFFFFF'\">"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"60\" rowspan=\"4\" align=\"center\" class=\"IDTD\" ID=\"blackIndexNO"+ReturnData.Lists[i].BlackID+"TD\">"+parseInt(i+1)+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"140\" class=\"objTitle\">IP地址段低地址：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"\" ID=\"blackLow"+ReturnData.Lists[i].BlackID+"TD\" class=\"underLine\">"+ReturnData.Lists[i].Low+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"100\" onclick=\"blackmodiBOX('"+ReturnData.Lists[i].BlackID+"')\" style=\"cursor:pointer;\"  class=\"underLine\" align=\"center\">"+"[修改配置]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">IP地址段高地址：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"blackHigh"+ReturnData.Lists[i].BlackID+"TD\" class=\"underLine\">"+ReturnData.Lists[i].High+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td onclick=\"blackdelCONBOX('"+ReturnData.Lists[i].BlackID+"')\" class=\"underLine\" style=\"cursor:pointer;\" align=\"center\">[删除配置]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">黑名单截止时间：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"blackExpire"+ReturnData.Lists[i].BlackID+"TD\" class=\"normal\">"+ReturnData.Lists[i].Expire+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td></td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\" class=\"objTitle\">"+"备注说明："+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"blackNote"+ReturnData.Lists[i].BlackID+"TD\" class=\"note\">"+ReturnData.Lists[i].Note+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td></td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				
				LISTHTML=LISTHTML+"	</table>"+"\n";
				LISTHTML=LISTHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n";
				LISTHTML=LISTHTML+"		<tr><td width=\"100%\" height=\"5\" background=\"image/line-5px.gif\"></td></tr>";
				LISTHTML=LISTHTML+"	</table>"+"\n";
				
				LISTHTML=LISTHTML+"</td></tr>"+"\n";

				//LISTHTML=LISTHTML+"<tr ID=\"black"+ReturnData.Lists[i].BlackID+"lineTR\"><td height=\"1\" background=\"image/line.gif\"></td></tr>"+"\n";
			}
		}
		LISTHTML="<table ID=\"blackTAB\" width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n"+LISTHTML+"\n"+"<BLACKLISTEND></table>"+"\n";
		document.getElementById("BLACKLIST").innerHTML=LISTHTML;
		//alert(LISTHTML);
	}
}


function blackadd(ReturnData){						//添加黑名单
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL==""){
			var boxURL="msg.htm?5.9";
			if(ReturnData.ErrorNo==40)boxURL="msg.htm?5.91";
		}
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		//============================================================
		//重新获取值，添加进当前列表
		var Low=document.getElementById("Low").value;
		var High=document.getElementById("High").value;
		var ExpireDate=document.getElementById("ExpireDate").value;
		var ExpireTime=document.getElementById("ExpireTime").value;
		var Expire=ExpireDate + " " + ExpireTime;
		var Note=document.getElementById("Note").value;
		//对新添加保护链HTML代码进行拼接
		//============================================================
		var ADDHTML="";
		var tabROWS=parent.document.getElementById("blackTAB").rows.length;
		var nowHTML=parent.document.getElementById("BLACKLIST").innerHTML;
		var nowData=1;//当前是否有已配置数据，默认为有(1)
		if(nowHTML.indexOf("未设置任何黑名单")!=-1)nowData=0;
		if(nowData==0){
			addROWID=1;
		}else{
			addROWID=parseInt(tabROWS)+1;
		}
				ADDHTML=ADDHTML+"<tr ID=\"black"+ReturnData.BlackID+"TR\"><td width=\"100%\">"+"\n";
				ADDHTML=ADDHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"  onMouseOver=\"javascript:this.style.backgroundColor='#EFF5FB'\" onMouseOut=\"javascript:this.style.backgroundColor='#FFFFFF'\">"+"\n";
				
				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td width=\"60\" rowspan=\"4\" align=\"center\" class=\"IDTD\" ID=\"blackIndexNO"+ReturnData.BlackID+"TD\">"+addROWID+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td width=\"140\" class=\"objTitle\">IP地址段低地址：</td>"+"\n";
				ADDHTML=ADDHTML+"			<td width=\"\" ID=\"blackLow"+ReturnData.BlackID+"TD\" class=\"underLine\">"+Low+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td width=\"100\" onclick=\"blackmodiBOX('"+ReturnData.BlackID+"')\" style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">"+"[修改配置]</td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";
				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td class=\"objTitle\">IP地址段高地址：</td>"+"\n";
				ADDHTML=ADDHTML+"			<td ID=\"blackHigh"+ReturnData.BlackID+"TD\" class=\"underLine\">"+High+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td onclick=\"blackdelCONBOX('"+ReturnData.BlackID+"')\" style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">[删除配置]</td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";
				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td class=\"objTitle\">黑名单截止时间：</td>"+"\n";
				ADDHTML=ADDHTML+"			<td ID=\"blackExpire"+ReturnData.BlackID+"TD\" class=\"normal\">"+Expire+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td></td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";
				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td class=\"objTitle\">"+"备注说明："+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td ID=\"blackNote"+ReturnData.BlackID+"TD\" class=\"note\">"+Note+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td></td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";

				ADDHTML=ADDHTML+"	</table>"+"\n";
				ADDHTML=ADDHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n";
				ADDHTML=ADDHTML+"		<tr><td width=\"100%\" height=\"5\" background=\"image/line-5px.gif\"></td></tr>";
				ADDHTML=ADDHTML+"	</table>"+"\n";

				ADDHTML=ADDHTML+"</td></tr>"+"\n";


		//alert(ADDHTML);
		//============================================================
		//获取当前内容，将新加内容进行拼接，写回
		
		if(nowData==0){
			var LISTHTML="<table ID=\"blackTAB\" width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n"+ADDHTML+"\n"+"<BLACKLISTEND></table>";
		}else{
			if(Sys.ie){
				var SPLITCHAR="<BLACKLISTEND>";
			}else{
				var SPLITCHAR="<blacklistend>";
			}
			//alert(nowHTML);
			nowHTML=nowHTML.split(SPLITCHAR)[0];
			var LISTHTML=nowHTML+ADDHTML+"<BLACKLISTEND></table>";
		}
		//alert(LISTHTML);
		parent.document.getElementById("BLACKLIST").innerHTML=LISTHTML;
		//============================================================		

		var boxURL="msg.htm?6.0";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		parent.document.documentElement.scrollTop=parent.document.documentElement.scrollHeight;
	}
	document.getElementById("blackADDbutton").src="image/black-add-button.gif";	//修改BUTTON
}

function blackviewset(ReturnData){				//获取黑名单配置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?6.1";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		if(ReturnData.NumOfLists==0){
			var boxURL="msg.htm?6.2";
			showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		}else{
			var BlackID=ReturnData.Lists[0].BlackID;
			document.getElementById("Low").value=ReturnData.Lists[0].Low;
			document.getElementById("High").value=ReturnData.Lists[0].High;
			document.getElementById("Note").value=ReturnData.Lists[0].Note;
			var Expire=ReturnData.Lists[0].Expire;
			Expire=Expire.split(" ");
			var ExpireDate=Expire[0];
			var ExpireTime=Expire[1];
			document.getElementById("ExpireDate").value=ExpireDate;
			document.getElementById("ExpireTime").value=ExpireTime;s
		}
	}
}

function blackmodi(ReturnData){					//修改黑名单配置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL==""){
			var boxURL="msg.htm?6.3";
			if(ReturnData.ErrorNo==41)boxURL="msg.htm?6.31";
		}
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var boxURL="msg.htm?6.4";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		//============================================
		//修改列表中内容
		var BlackID=ReturnData.BlackID;
		var Low=document.getElementById("Low").value;
		var High=document.getElementById("High").value;
		var ExpireDate=document.getElementById("ExpireDate").value;
		var ExpireTime=document.getElementById("ExpireTime").value;
		var Expire=ExpireDate + " " + ExpireTime;
		var Note=document.getElementById("Note").value;
		
		parent.document.getElementById("blackLow"+BlackID+"TD").innerHTML=Low;
		parent.document.getElementById("blackHigh"+BlackID+"TD").innerHTML=High;
		parent.document.getElementById("blackExpire"+BlackID+"TD").innerHTML=Expire;
		parent.document.getElementById("blackNote"+BlackID+"TD").innerHTML=Note;
	}
	document.getElementById("blackMODIbutton").src="image/black-modi-button.gif";
}

function blackdel(ReturnData){					//删除黑名单
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?6.5";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		//改变删除方法
		var strTR=document.getElementById("black"+ReturnData.BlackID+"TR").rowIndex;
		var strTAB=document.getElementById("blackTAB");
		strTAB.deleteRow(strTR);	
		resetIndexNO('black','0',1);			//重新排序
		var boxURL="msg.htm?6.6";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}
}


//===========================================================================================================
//以下为分量统计管理部分
function statlist(ReturnData){					//获取当前分量统计列表
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?6.8";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var LISTHTML="";
		if(ReturnData.NumOfLists==0){
			LISTHTML="<tr><td width=\"100%\" height=\"300\" align=\"center\">当前未设置任何分量统计，请使用页面右下角的添加分量统计功能进行添加。</td></tr>";
		}else{
			for(var i=0;i<ReturnData.NumOfLists;i++){
				if(ReturnData.Lists[i].Icase==0)var Icase="不忽略";		//是否忽略大小写，0：不忽略；1：忽略;
				if(ReturnData.Lists[i].Icase==1)var Icase="忽略";
				if(ReturnData.Lists[i].Rules==0)var Rules="通配符匹配";		// 匹配规则, 通配符匹配(0), 正则表达式匹配(1), 精确匹配(2), 默认(0);
				if(ReturnData.Lists[i].Rules==1)var Rules="正则表达式匹配";
				if(ReturnData.Lists[i].Rules==2)var Rules="精确匹配";
				LISTHTML=LISTHTML+"<tr ID=\"stat"+ReturnData.Lists[i].StatID+"TR\"><td width=\"100%\">"+"\n";
				LISTHTML=LISTHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"  onMouseOver=\"javascript:this.style.backgroundColor='#EFF5FB'\" onMouseOut=\"javascript:this.style.backgroundColor='#FFFFFF'\">"+"\n";
				
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"60\" rowspan=\"5\" align=\"center\" class=\"IDTD\"  ID=\"statIndexNO"+ReturnData.Lists[i].StatID+"TD\">"+parseInt(i+1)+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"140\" class=\"objTitle\">分量统计URL：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"\" ID=\"statStatUrl"+ReturnData.Lists[i].StatID+"TD\" class=\"underLine\">"+ReturnData.Lists[i].StatUrl+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"100\" onclick=\"statmodiBOX('"+ReturnData.Lists[i].StatID+"')\" style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">"+"[修改配置]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">URL匹配规则：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"statRules"+ReturnData.Lists[i].StatID+"TD\" class=\"normal\">"+Rules+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td onclick=\"statdelCONBOX('"+ReturnData.Lists[i].StatID+"')\" style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">[删除配置]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">忽略大小写：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"statIcase"+ReturnData.Lists[i].StatID+"TD\" class=\"normal\">"+Icase+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td onclick=\"statupPOST('"+ReturnData.Lists[i].StatID+"')\" style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">[进行上移]</td></td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">"+"备注说明："+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"statNote"+ReturnData.Lists[i].StatID+"TD\" class=\"note\">"+ReturnData.Lists[i].Note+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td onclick=\"statdownPOST('"+ReturnData.Lists[i].StatID+"')\" style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">[进行下移]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td>"+""+"</td>"+"\n";
				//LISTHTML=LISTHTML+"			<td onclick=\"viewitemstatrealtimereport('"+ReturnData.Lists[i].StatID+"')\" style=\"cursor:pointer;\" class=\"underLine\">"+"点击查看此分量统计的实时报告"+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"underLine\">"+"<a href=\"javascript:viewitemstatrealtimereport('"+ReturnData.Lists[i].StatID+"')\">点击查看此分量统计的实时报告</a>"+"</td>"+"\n";

				LISTHTML=LISTHTML+"			<td></td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";


				LISTHTML=LISTHTML+"	</table>"+"\n";
				LISTHTML=LISTHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n";
				LISTHTML=LISTHTML+"		<tr><td width=\"100%\" height=\"5\" background=\"image/line-5px.gif\"></td></tr>";
				LISTHTML=LISTHTML+"	</table>"+"\n";
				
				LISTHTML=LISTHTML+"</td></tr>"+"\n";
			}
		}
		LISTHTML="<table ID=\"statTAB\" width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n"+LISTHTML+"\n"+"<STATLISTEND></table>"+"\n";
		document.getElementById("STATLIST").innerHTML=LISTHTML;
		//alert(LISTHTML);
	}
}

function statadd(ReturnData){						//添加分量统计
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL==""){
			var boxURL="msg.htm?6.9";
			if(ReturnData.ErrorNo==80)boxURL="msg.htm?6.91";
		}
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		//============================================================
		//重新获取值，添加进当前列表
		var StatUrl=document.getElementById("StatUrl").value;
		var IcaseOBJ=document.getElementsByName("Icase");
		for(i=0;i<IcaseOBJ.length;i++){
			if(IcaseOBJ[i].checked==true)var Icase=IcaseOBJ[i].value;
		}

		if(Icase==0)Icase="不忽略";					//是否忽略大小写，0：不忽略；1：忽略;;
		if(Icase==1)Icase="忽略";
		var RulesOBJ=document.getElementsByName("Rules");
		for(i=0;i<RulesOBJ.length;i++){
			if(RulesOBJ[i].checked==true)var Rules=RulesOBJ[i].value;
		}
		if(Rules==0)Rules="通配符匹配";		//分量统计 URL 匹配规则, 使用通配符匹配(0), 使用正则表达式匹配(1), 精确匹配(2),  
		if(Rules==1)Rules="正则表达式匹配";
		if(Rules==2)Rules="精确匹配";
		var Note=document.getElementById("Note").value;

		//对新添加分量统计HTML代码进行拼接
		//============================================================
		var ADDHTML="";
		var tabROWS=parent.document.getElementById("statTAB").rows.length;
		//alert(tabROWS);
		var nowHTML=parent.document.getElementById("STATLIST").innerHTML;
		var nowData=1;//当前是否有已配置数据，默认为有(1)
		if(nowHTML.indexOf("未设置任何分量统计")!=-1)nowData=0;
		if(nowData==0){
			addROWID=1;
		}else{
			addROWID=parseInt(tabROWS)+1;
		}

		ADDHTML=ADDHTML+"<tr ID=\"stat"+ReturnData.StatID+"TR\"><td width=\"100%\">"+"\n";
		ADDHTML=ADDHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"  onMouseOver=\"javascript:this.style.backgroundColor='#EFF5FB'\" onMouseOut=\"javascript:this.style.backgroundColor='#FFFFFF'\">"+"\n";
				
		ADDHTML=ADDHTML+"		<tr>"+"\n";
		ADDHTML=ADDHTML+"			<td width=\"60\" rowspan=\"5\" align=\"center\" class=\"IDTD\" ID=\"statIndexNO"+ReturnData.StatID+"TD\">"+addROWID+"</td>"+"\n";
		ADDHTML=ADDHTML+"			<td width=\"140\" class=\"objTitle\">分量统计URL：</td>"+"\n";
		ADDHTML=ADDHTML+"			<td width=\"\" ID=\"statStatUrl"+ReturnData.StatID+"TD\" class=\"underLine\">"+StatUrl+"</td>"+"\n";
		ADDHTML=ADDHTML+"			<td width=\"100\" onclick=\"statmodiBOX('"+ReturnData.StatID+"')\" style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">"+"[修改配置]</td>"+"\n";
		ADDHTML=ADDHTML+"		</tr>"+"\n";
		ADDHTML=ADDHTML+"		<tr>"+"\n";
		ADDHTML=ADDHTML+"			<td class=\"objTitle\">URL匹配规则：</td>"+"\n";
		ADDHTML=ADDHTML+"			<td ID=\"statRules"+ReturnData.StatID+"TD\" class=\"normal\">"+Rules+"</td>"+"\n";
		ADDHTML=ADDHTML+"			<td onclick=\"statdelCONBOX('"+ReturnData.StatID+"')\" style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">[删除配置]</td>"+"\n";
		ADDHTML=ADDHTML+"		</tr>"+"\n";
		ADDHTML=ADDHTML+"		<tr>"+"\n";
		ADDHTML=ADDHTML+"			<td class=\"objTitle\">是否忽略大小写：</td>"+"\n";
		ADDHTML=ADDHTML+"			<td ID=\"statIcase"+ReturnData.StatID+"TD\" class=\"normal\">"+Icase+"</td>"+"\n";
		ADDHTML=ADDHTML+"			<td onclick=\"statupPOST('"+ReturnData.StatID+"')\" style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">[进行上移]</td>"+"\n";
		ADDHTML=ADDHTML+"		</tr>"+"\n";
		ADDHTML=ADDHTML+"		<tr>"+"\n";
		ADDHTML=ADDHTML+"			<td class=\"objTitle\">"+"备注说明："+"</td>"+"\n";
		ADDHTML=ADDHTML+"			<td ID=\"statNote"+ReturnData.StatID+"TD\" class=\"note\">"+Note+"</td>"+"\n";
		ADDHTML=ADDHTML+"			<td onclick=\"statdownPOST('"+ReturnData.StatID+"')\" style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">[进行下移]</td>"+"\n";
		ADDHTML=ADDHTML+"		</tr>"+"\n";
		ADDHTML=ADDHTML+"		<tr>"+"\n";
		ADDHTML=ADDHTML+"			<td>"+""+"</td>"+"\n";
		//ADDHTML=ADDHTML+"			<td onclick=\"viewitemstatrealtimereport('"+ReturnData.StatID+"')\" style=\"cursor:pointer;\" class=\"underLine\">"+"点击查看此分量统计的实时报告"+"</td>"+"\n";
		ADDHTML=ADDHTML+"			<td class=\"underLine\">"+"<a href=\"javascript:viewitemstatrealtimereport('"+ReturnData.StatID+"')\">点击查看此分量统计的实时报告</a>"+"</td>"+"\n";
		ADDHTML=ADDHTML+"			<td></td>"+"\n";
		ADDHTML=ADDHTML+"		</tr>"+"\n";
				
		ADDHTML=ADDHTML+"	</table>"+"\n";
		ADDHTML=ADDHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n";
		ADDHTML=ADDHTML+"		<tr><td width=\"100%\" height=\"5\" background=\"image/line-5px.gif\"></td></tr>";
		ADDHTML=ADDHTML+"	</table>"+"\n";
				
		ADDHTML=ADDHTML+"</td></tr>"+"\n";
		//alert(ADDHTML);
		//============================================================
		//获取当前内容，将新加内容进行拼接，写回
		
		if(nowData==0){
			var LISTHTML="<table ID=\"statTAB\" width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n"+ADDHTML+"\n"+"<STATLISTEND></table>";
		}else{
			if(Sys.ie){
				var SPLITCHAR="<STATLISTEND>";
			}else{
				var SPLITCHAR="<statlistend>";
			}
	
			nowHTML=nowHTML.split(SPLITCHAR)[0];
			var LISTHTML=nowHTML+ADDHTML+"<STATLISTEND></table>";
		}
		//alert(LISTHTML);
		parent.document.getElementById("STATLIST").innerHTML=LISTHTML;
		//============================================================		

		var boxURL="msg.htm?7.0";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		parent.document.documentElement.scrollTop=parent.document.documentElement.scrollHeight;
	}
	document.getElementById("statADDbutton").src="image/stat-add-button.gif";	//修改BUTTON
}

function statviewset(ReturnData){				//获取分量统计配置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?7.1";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		if(ReturnData.NumOfLists==0){
			var boxURL="msg.htm?7.2";
			showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		}else{
			var StatID=ReturnData.Lists[0].StatID;
			document.getElementById("StatUrl").value=ReturnData.Lists[0].StatUrl;
			var Icase=ReturnData.Lists[0].Icase;
			var IcaseOBJ=document.getElementsByName("Icase");
			for(i=0;i<IcaseOBJ.length;i++){
				if(IcaseOBJ[i].value==Icase)IcaseOBJ[i].checked=true;
			}
			var Rules=ReturnData.Lists[0].Rules;
			var RulesOBJ=document.getElementsByName("Rules");
			for(i=0;i<RulesOBJ.length;i++){
				if(RulesOBJ[i].value==Rules)RulesOBJ[i].checked=true;
			}
			document.getElementById("Note").value=ReturnData.Lists[0].Note;
		}
	}
}
		
function statmodi(ReturnData){					//修改分量统计配置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL==""){
			var boxURL="msg.htm?7.3";
			if(ReturnData.ErrorNo==81)boxURL="msg.htm?7.31";
		}
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var boxURL="msg.htm?7.4";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		//============================================
		//修改列表中内容
		var StatID=ReturnData.StatID;
		var StatUrl=document.getElementById("StatUrl").value;
		var IcaseOBJ=document.getElementsByName("Icase");
		for(i=0;i<IcaseOBJ.length;i++){
			if(IcaseOBJ[i].checked==true)var Icase=IcaseOBJ[i].value;
		}//分量统计 URL 匹配规则, 使用通配符匹配(0), 使用正则表达式匹配(1), 精确匹配(2),
		if(Icase==0)Icase="不忽略";
		if(Icase==1)Icase="忽略";
		var RulesOBJ=document.getElementsByName("Rules");
		for(i=0;i<RulesOBJ.length;i++){
			if(RulesOBJ[i].checked==true)var Rules=RulesOBJ[i].value;
		}
		if(Rules==0)Rules="通配符匹配";
		if(Rules==1)Rules="正则表达式匹配";
		if(Rules==2)Rules="精确匹配";
		var Note=document.getElementById("Note").value;
		
		parent.document.getElementById("statStatUrl"+StatID+"TD").innerHTML=StatUrl;
		parent.document.getElementById("statIcase"+StatID+"TD").innerHTML=Icase;
		parent.document.getElementById("statRules"+StatID+"TD").innerHTML=Rules;
		parent.document.getElementById("statNote"+StatID+"TD").innerHTML=Note;
	}
	document.getElementById("statMODIbutton").src="image/stat-modi-button.gif";
}

function statdel(ReturnData){					//删除分量统计
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?7.5";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		//改变删除方法
		var strTR=document.getElementById("stat"+ReturnData.StatID+"TR").rowIndex;
		var strTAB=document.getElementById("statTAB");
		strTAB.deleteRow(strTR);
		resetIndexNO('stat','0',1);			//重新排序
		var boxURL="msg.htm?7.6";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}
}

function statup(ReturnData){					//分量统计上移
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?7.8";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		moveUp('stat',ReturnData.StatID,'7.9');
	}
	//成功提示后，调用函数moveUp(ACTNAME,clickID)进行页面换行操作
	//moveUp('stat',ReturnData.StatID);
}

function statdown(ReturnData){					//分量统计下移
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?8.0";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		moveDown('stat',ReturnData.StatID,'8.1');
	}
}

//分量统计的统计报告函数在实时统计中
//===========================================================================================================
//以下为转向管理部分
function rewritelist(ReturnData){					//获取当前转向管理列表

	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?8.2";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var LISTHTML="";
		if(ReturnData.NumOfLists==0){
			LISTHTML="<tr><td width=\"100%\" height=\"300\" align=\"center\">当前未设置任何转向管理，请使用页面右下角的添加转向管理功能进行添加。</td></tr>";
		}else{
			for(var i=0;i<ReturnData.NumOfLists;i++){
				if(ReturnData.Lists[i].Icase==0)var Icase="不忽略";		//是否忽略大小写，0：不忽略；1：忽略;
				if(ReturnData.Lists[i].Icase==1)var Icase="忽略";
				if(ReturnData.Lists[i].Flag==0)var Flag="Last";			// 转向逻辑：(a). Last(0) 默认选项;(b). Return(1);(c). Round(2);(d). Continue(3);
				if(ReturnData.Lists[i].Flag==1)var Flag="Return";
				if(ReturnData.Lists[i].Flag==2)var Flag="Round";
				if(ReturnData.Lists[i].Flag==3)var Flag="Continue";
				LISTHTML=LISTHTML+"<tr ID=\"rewrite"+ReturnData.Lists[i].RewriteID+"TR\"><td width=\"100%\">"+"\n";
				LISTHTML=LISTHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"  onMouseOver=\"javascript:this.style.backgroundColor='#EFF5FB'\" onMouseOut=\"javascript:this.style.backgroundColor='#FFFFFF'\">"+"\n";
				
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"60\" rowspan=\"5\" align=\"center\" class=\"IDTD\" ID=\"rewriteIndexNO"+ReturnData.Lists[i].RewriteID+"TD\">"+parseInt(i+1)+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"140\" class=\"objTitle\">访问地址URL：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"\" ID=\"rewriteSourceUrl"+ReturnData.Lists[i].RewriteID+"TD\" class=\"underLine\">"+ReturnData.Lists[i].SourceUrl+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"100\" onclick=\"rewritemodiBOX('"+ReturnData.Lists[i].RewriteID+"')\" align=\"center\" style=\"cursor:pointer;\" class=\"underLine\">"+"[修改配置]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">转向地址URL：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"rewriteDestinationUrl"+ReturnData.Lists[i].RewriteID+"TD\" class=\"underLine\">"+ReturnData.Lists[i].DestinationUrl+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td onclick=\"rewritedelCONBOX('"+ReturnData.Lists[i].RewriteID+"')\" align=\"center\" style=\"cursor:pointer;\" class=\"underLine\">[删除配置]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">是否忽略大小写：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"rewriteIcase"+ReturnData.Lists[i].RewriteID+"TD\" class=\"normal\">"+Icase+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td onclick=\"rewriteupPOST('"+ReturnData.Lists[i].RewriteID+"')\" align=\"center\" style=\"cursor:pointer;\" class=\"underLine\">[进行上移]</td></td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">转向逻辑：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"rewriteFlag"+ReturnData.Lists[i].RewriteID+"TD\" class=\"normal\">"+Flag+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td onclick=\"rewritedownPOST('"+ReturnData.Lists[i].RewriteID+"')\" align=\"center\" style=\"cursor:pointer;\" class=\"underLine\">[进行下移]</td></td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">"+"备注说明："+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"rewriteNote"+ReturnData.Lists[i].RewriteID+"TD\" class=\"note\">"+ReturnData.Lists[i].Note+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td></td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";

				LISTHTML=LISTHTML+"	</table>"+"\n";
				LISTHTML=LISTHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n";
				LISTHTML=LISTHTML+"		<tr><td width=\"100%\" height=\"5\" background=\"image/line-5px.gif\"></td></tr>";
				LISTHTML=LISTHTML+"	</table>"+"\n";
				
				LISTHTML=LISTHTML+"</td></tr>"+"\n";
			}
		}
		LISTHTML="<table ID=\"rewriteTAB\" width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n"+LISTHTML+"\n"+"<REWRITELISTEND></table>"+"\n";
		document.getElementById("REWRITELIST").innerHTML=LISTHTML;
		//alert(LISTHTML);
	}
}

function rewriteadd(ReturnData){						//添加转向管理
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL==""){
			var boxURL="msg.htm?8.3";
			if(ReturnData.ErrorNo==60)boxURL="msg.htm?8.31";
		}
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		//============================================================
		//重新获取值，添加进当前列表
		var SourceUrl=document.getElementById("SourceUrl").value;
		var DestinationUrl=document.getElementById("DestinationUrl").value;
		var IcaseOBJ=document.getElementsByName("Icase");
		for(i=0;i<IcaseOBJ.length;i++){
			if(IcaseOBJ[i].checked==true)var Icase=IcaseOBJ[i].value;
		}

		if(Icase==0)Icase="不忽略";					//是否忽略大小写，0：不忽略；1：忽略;;
		if(Icase==1)Icase="忽略";
		var FlagOBJ=document.getElementsByName("Flag");
		for(i=0;i<FlagOBJ.length;i++){
			if(FlagOBJ[i].checked==true)var Flag=FlagOBJ[i].value;
		}
		if(Flag==0)Flag="Last";		//转向逻辑, //(a). Last(0) 默认选项;//(b). Return(1);//(c). Round(2);//(d). Continue(3); 
		if(Flag==1)Flag="Return";
		if(Flag==2)Flag="Round";
		if(Flag==3)Flag="Continue";
		var Note=document.getElementById("Note").value;

		//对新添加转向管理HTML代码进行拼接
		//============================================================
		var ADDHTML="";
		var tabROWS=parent.document.getElementById("rewriteTAB").rows.length;
		var nowHTML=parent.document.getElementById("REWRITELIST").innerHTML;
		var nowData=1;//当前是否有已配置数据，默认为有(1)
		if(nowHTML.indexOf("未设置任何转向管理")!=-1)nowData=0;
		if(nowData==0){
			addROWID=1;
		}else{
			addROWID=parseInt(tabROWS)+1;
		}

		ADDHTML=ADDHTML+"<tr ID=\"rewrite"+ReturnData.RewriteID+"TR\"><td width=\"100%\">"+"\n";
		ADDHTML=ADDHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"  onMouseOver=\"javascript:this.style.backgroundColor='#EFF5FB'\" onMouseOut=\"javascript:this.style.backgroundColor='#FFFFFF'\">"+"\n";
				
		ADDHTML=ADDHTML+"		<tr>"+"\n";
		ADDHTML=ADDHTML+"			<td width=\"60\" rowspan=\"5\" align=\"center\" class=\"IDTD\" ID=\"rewriteIndexNO"+ReturnData.RewriteID+"TD\">"+addROWID+"</td>"+"\n";
		ADDHTML=ADDHTML+"			<td width=\"140\" class=\"objTitle\">访问地址URL：</td>"+"\n";
		ADDHTML=ADDHTML+"			<td width=\"\" ID=\"rewriteSourceUrl"+ReturnData.RewriteID+"TD\" class=\"underLine\">"+SourceUrl+"</td>"+"\n";
		ADDHTML=ADDHTML+"			<td width=\"100\" onclick=\"rewritemodiBOX('"+ReturnData.RewriteID+"')\" align=\"center\" style=\"cursor:pointer;\" class=\"underLine\">"+"[修改配置]</td>"+"\n";
		ADDHTML=ADDHTML+"		</tr>"+"\n";
		ADDHTML=ADDHTML+"		<tr>"+"\n";
		ADDHTML=ADDHTML+"			<td class=\"objTitle\">转向地址URL：</td>"+"\n";
		ADDHTML=ADDHTML+"			<td ID=\"rewriteDestinationUrl"+ReturnData.RewriteID+"TD\" class=\"underLine\">"+DestinationUrl+"</td>"+"\n";
		ADDHTML=ADDHTML+"			<td onclick=\"rewritedelCONBOX('"+ReturnData.RewriteID+"')\" align=\"center\" style=\"cursor:pointer;\" class=\"underLine\">[删除配置]</td>"+"\n";
		ADDHTML=ADDHTML+"		</tr>"+"\n";
		ADDHTML=ADDHTML+"		<tr>"+"\n";
		ADDHTML=ADDHTML+"			<td class=\"objTitle\">是否忽略大小写：</td>"+"\n";
		ADDHTML=ADDHTML+"			<td ID=\"rewriteIcase"+ReturnData.RewriteID+"TD\" class=\"normal\">"+Icase+"</td>"+"\n";
		ADDHTML=ADDHTML+"			<td onclick=\"rewriteupPOST('"+ReturnData.RewriteID+"')\" align=\"center\" style=\"cursor:pointer;\" class=\"underLine\">[进行上移]</td>"+"\n";
		ADDHTML=ADDHTML+"		</tr>"+"\n";
		ADDHTML=ADDHTML+"		<tr>"+"\n";
		ADDHTML=ADDHTML+"			<td class=\"objTitle\">转向逻辑：</td>"+"\n";
		ADDHTML=ADDHTML+"			<td ID=\"rewriteFlag"+ReturnData.RewriteID+"TD\" class=\"normal\">"+Flag+"</td>"+"\n";
		ADDHTML=ADDHTML+"			<td onclick=\"rewritedownPOST('"+ReturnData.RewriteID+"')\" align=\"center\" style=\"cursor:pointer;\" class=\"underLine\">[进行下移]</td>"+"\n";
		ADDHTML=ADDHTML+"		</tr>"+"\n";
		
		ADDHTML=ADDHTML+"		<tr>"+"\n";
		ADDHTML=ADDHTML+"			<td class=\"objTitle\" class=\"note\">"+"备注说明："+"</td>"+"\n";
		ADDHTML=ADDHTML+"			<td ID=\"rewriteNote"+ReturnData.RewriteID+"TD\" class=\"note\">"+Note+"</td>"+"\n";
		ADDHTML=ADDHTML+"			<td></td>"+"\n";
		ADDHTML=ADDHTML+"		</tr>"+"\n";	

		ADDHTML=ADDHTML+"	</table>"+"\n";
		ADDHTML=ADDHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n";
		ADDHTML=ADDHTML+"		<tr><td width=\"100%\" height=\"5\" background=\"image/line-5px.gif\"></td></tr>";
		ADDHTML=ADDHTML+"	</table>"+"\n";
		
		ADDHTML=ADDHTML+"</td></tr>"+"\n";
		
		
		if(nowData==0){
			var LISTHTML="<table ID=\"rewriteTAB\" width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n"+ADDHTML+"\n"+"<REWRITELISTEND></table>";
		}else{
			if(Sys.ie){
				var SPLITCHAR="<REWRITELISTEND>";
			}else{
				var SPLITCHAR="<rewritelistend>";
			}
	
			nowHTML=nowHTML.split(SPLITCHAR)[0];
			var LISTHTML=nowHTML+ADDHTML+"<REWRITELISTEND></table>";
		}
				//alert(LISTHTML);
		parent.document.getElementById("REWRITELIST").innerHTML=LISTHTML;
				//============================================================		

		var boxURL="msg.htm?8.4";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		parent.document.documentElement.scrollTop=parent.document.documentElement.scrollHeight;
	}
	document.getElementById("rewriteADDbutton").src="image/rewrite-add-button.gif";	//修改BUTTON
}
function rewriteviewset(ReturnData){				//获取转向管理配置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?8.5";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		if(ReturnData.NumOfLists==0){
			var boxURL="msg.htm?8.6";
			showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		}else{
			var RewriteID=ReturnData.Lists[0].RewriteID;
			document.getElementById("SourceUrl").value=ReturnData.Lists[0].SourceUrl;
			document.getElementById("DestinationUrl").value=ReturnData.Lists[0].DestinationUrl;
			var Icase=ReturnData.Lists[0].Icase;
			var IcaseOBJ=document.getElementsByName("Icase");
			for(i=0;i<IcaseOBJ.length;i++){
				if(IcaseOBJ[i].value==Icase)IcaseOBJ[i].checked=true;
			}
			var Flag=ReturnData.Lists[0].Flag;
			var FlagOBJ=document.getElementsByName("Flag");
			for(i=0;i<FlagOBJ.length;i++){
				if(FlagOBJ[i].value==Flag)FlagOBJ[i].checked=true;
			}
			document.getElementById("Note").value=ReturnData.Lists[0].Note;
		}
	}
}
function rewritemodi(ReturnData){					//修改转向管理配置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL==""){
			var boxURL="msg.htm?8.7";
			if(ReturnData.ErrorNo==61)boxURL="msg.htm?8.71";
		}
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var boxURL="msg.htm?8.8";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		//============================================
		//修改列表中内容
		var RewriteID=ReturnData.RewriteID;
		var SourceUrl=document.getElementById("SourceUrl").value;
		var DestinationUrl=document.getElementById("DestinationUrl").value;
		var IcaseOBJ=document.getElementsByName("Icase");
		for(i=0;i<IcaseOBJ.length;i++){
			if(IcaseOBJ[i].checked==true)var Icase=IcaseOBJ[i].value;
		}
		if(Icase==0)Icase="不忽略";
		if(Icase==1)Icase="忽略";
		var FlagOBJ=document.getElementsByName("Flag");
		for(i=0;i<FlagOBJ.length;i++){
			if(FlagOBJ[i].checked==true)var Flag=FlagOBJ[i].value;
		}//转向逻辑(a). Last(0) 默认选项;(b). Return(1);(c). Round(2);(d). Continue(3);
		if(Flag==0)Flag="Last";
		if(Flag==1)Flag="Return";
		if(Flag==2)Flag="Round";
		if(Flag==3)Flag="Continue";
		var Note=document.getElementById("Note").value;
		
		parent.document.getElementById("rewriteSourceUrl"+RewriteID+"TD").innerHTML=SourceUrl;
		parent.document.getElementById("rewriteDestinationUrl"+RewriteID+"TD").innerHTML=DestinationUrl;
		parent.document.getElementById("rewriteIcase"+RewriteID+"TD").innerHTML=Icase;
		parent.document.getElementById("rewriteFlag"+RewriteID+"TD").innerHTML=Flag;
		parent.document.getElementById("rewriteNote"+RewriteID+"TD").innerHTML=Note;
	}
	document.getElementById("rewriteMODIbutton").src="image/rewrite-modi-button.gif";
}

function rewritedel(ReturnData){					//删除转向管理
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?8.9";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		//改变删除方法
		var strTR=document.getElementById("rewrite"+ReturnData.RewriteID+"TR").rowIndex;
		var strTAB=document.getElementById("rewriteTAB");
		strTAB.deleteRow(strTR);	
		resetIndexNO('rewrite','0',1);			//重新排序
		var boxURL="msg.htm?9.0";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}
}

function rewriteup(ReturnData){						//转向管理上移
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?9.2";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		moveUp('rewrite',ReturnData.RewriteID,'9.3');
	}
}

function rewritedown(ReturnData){					//转向管理下移
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?9.4";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		moveDown('rewrite',ReturnData.RewriteID,'9.5');
	}
}



//===========================================================================================================
//以下为页面缓存部分
function fcachelist(ReturnData){					//获取当前页面缓存列表
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?9.6";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var LISTHTML="";
		if(ReturnData.NumOfLists==0){
			LISTHTML="<tr><td width=\"100%\" height=\"300\" align=\"center\">当前未设置任何页面缓存，请使用页面右下角的添加页面缓存功能进行添加。</td></tr>";
		}else{
			for(var i=0;i<ReturnData.NumOfLists;i++){
				if(ReturnData.Lists[i].Icase==0)var Icase="不忽略";			//是否忽略大小写，0：不忽略；1：忽略;
				if(ReturnData.Lists[i].Icase==1)var Icase="忽略";
				if(ReturnData.Lists[i].Rules==0)var Rules="通配符匹配";		//Rules 	Url匹配规则, 通配符匹配(0), 正则表达式匹配(1), 精确匹配(2), 缺省(0);	
				if(ReturnData.Lists[i].Rules==1)var Rules="正则表达式匹配";
				if(ReturnData.Lists[i].Rules==2)var Rules="精确匹配";
				if(ReturnData.Lists[i].Unit==0)var Unit="天";				//Unit 	时间单位, 天(0), 小时(1), 分钟(2), 秒(3), 缺省(0);
				if(ReturnData.Lists[i].Unit==1)var Unit="小时";	
				if(ReturnData.Lists[i].Unit==2)var Unit="分钟";
				if(ReturnData.Lists[i].Unit==3)var Unit="秒";
				if(ReturnData.Lists[i].Icookie==0)var Icookie="缓存时不忽略";	//Icookie  是否忽略 Cookie 不忽略(0), 忽略(1), 缺省(1);
				if(ReturnData.Lists[i].Icookie==1)var Icookie="缓存时忽略";
				if(ReturnData.Lists[i].Olimit==0)var Olimit="所有用户";		//Olimit  开放权限 所有用户 登录用户 游客用户
				if(ReturnData.Lists[i].Olimit==1)var Olimit="登录用户";
				if(ReturnData.Lists[i].Olimit==2)var Olimit="游客用户";
				LISTHTML=LISTHTML+"<tr ID=\"fcache"+ReturnData.Lists[i].Wid+"TR\"><td width=\"100%\">"+"\n";
				LISTHTML=LISTHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"  onMouseOver=\"javascript:this.style.backgroundColor='#EFF5FB'\" onMouseOut=\"javascript:this.style.backgroundColor='#FFFFFF'\">"+"\n";
			
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"60\" rowspan=\"6\" align=\"center\" ID=\"fcacheIndexNO"+ReturnData.Lists[i].Wid+"TD\" class=\"IDTD\">"+parseInt(i+1)+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"140\" class=\"objTitle\">缓存地址URL：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"fcacheUrl"+ReturnData.Lists[i].Wid+"TD\" class=\"underLine\">"+ReturnData.Lists[i].Url+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"100\" onclick=\"fcachemodiBOX('"+ReturnData.Lists[i].Wid+"')\" style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">"+"[修改配置]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">URL匹配规则：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"fcacheIcase"+ReturnData.Lists[i].Wid+"TD\" class=\"normal\">"+Rules+"（匹配时"+Icase+"大小写）"+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td onclick=\"fcachedelCONBOX('"+ReturnData.Lists[i].Wid+"')\" style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">[删除配置]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">超时周期：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"fcacheExpire"+ReturnData.Lists[i].Wid+"TD\" class=\"normal\">"+ReturnData.Lists[i].Expire+""+Unit+""+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td onclick=\"fcacheupPOST('"+ReturnData.Lists[i].Wid+"')\" style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">[进行上移]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">忽略Set\-Cookie：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"fcacheIcookie"+ReturnData.Lists[i].Wid+"TD\" class=\"normal\">"+Icookie+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td onclick=\"fcachedownPOST('"+ReturnData.Lists[i].Wid+"')\" style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">[进行下移]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">开放权限：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"fcacheOlimit"+ReturnData.Lists[i].Wid+"TD\" class=\"normal\">"+Olimit+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td>&nbsp;</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">"+"备注说明："+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"fcacheNote"+ReturnData.Lists[i].Wid+"TD\" class=\"note\">"+ReturnData.Lists[i].Note+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td></td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";

				LISTHTML=LISTHTML+"	</table>"+"\n";
				LISTHTML=LISTHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n";
				LISTHTML=LISTHTML+"		<tr><td width=\"100%\" height=\"5\" background=\"image/line-5px.gif\"></td></tr>";
				LISTHTML=LISTHTML+"	</table>"+"\n";
				
				LISTHTML=LISTHTML+"</td></tr>"+"\n";
			}
		}
		LISTHTML="<table ID=\"fcacheTAB\" width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n"+LISTHTML+"\n"+"<FCACHELISTEND></table>"+"\n";
		document.getElementById("FCACHELIST").innerHTML=LISTHTML;
		//alert(LISTHTML);
	}
}


function fcacheadd(ReturnData){						//添加页面缓存
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL==""){
			var boxURL="msg.htm?9.7";
			if(ReturnData.ErrorNo==30)boxURL="msg.htm?9.71";
		}
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		//============================================================
		//重新获取值，添加进当前列表
		var Url=document.getElementById("Url").value;
		var Expire=document.getElementById("Expire").value;
		var IcaseOBJ=document.getElementsByName("Icase");
			for(i=0;i<IcaseOBJ.length;i++){
				if(IcaseOBJ[i].checked==true)var Icase=IcaseOBJ[i].value;
			}//是否忽略大小写，0：不忽略；1：忽略;
			if(Icase==0)Icase="不忽略";				
			if(Icase==1)Icase="忽略";
		var RulesOBJ=document.getElementsByName("Rules");
			for(i=0;i<RulesOBJ.length;i++){
				if(RulesOBJ[i].checked==true)var Rules=RulesOBJ[i].value;
			}//Url匹配规则, 通配符匹配(0), 正则表达式匹配(1), 精确匹配(2), 缺省(0);
			if(Rules==0)Rules="通配符匹配";					
			if(Rules==1)Rules="正则表达式匹配";
			if(Rules==2)Rules="精确匹配";
		var UnitOBJ=document.getElementsByName("Unit");
			for(i=0;i<UnitOBJ.length;i++){
				if(UnitOBJ[i].checked==true)var Unit=UnitOBJ[i].value;
			}//Unit 	时间单位, 天(0), 小时(1), 分钟(2), 秒(3), 缺省(0)
			if(Unit==0)Unit="天";		
			if(Unit==1)Unit="小时";
			if(Unit==2)Unit="分钟";
			if(Unit==3)Unit="秒";
		var IcookieOBJ=document.getElementsByName("Icookie");
			for(i=0;i<IcookieOBJ.length;i++){
				if(IcookieOBJ[i].checked==true)var Icookie=IcookieOBJ[i].value;
			}//Icookie  是否忽略 Cookie 不忽略(0), 忽略(1), 缺省(1)
			if(Icookie==0)Icookie="缓存时不忽略";					
			if(Icookie==1)Icookie="缓存时忽略";
		var OlimitOBJ=document.getElementsByName("Olimit");
			for(i=0;i<OlimitOBJ.length;i++){
				if(OlimitOBJ[i].checked==true)var Olimit=OlimitOBJ[i].value;
			}//Olimit  开放权限 所有用户 登录用户  游客用户
			if(Olimit==0)Olimit="所有用户";					
			if(Olimit==1)Olimit="登录用户";
			if(Olimit==2)Olimit="游客用户";
		var Note=document.getElementById("Note").value;

		//对新添加页面缓存HTML代码进行拼接
		//============================================================
		var ADDHTML="";
		var tabROWS=parent.document.getElementById("fcacheTAB").rows.length;
		var nowHTML=parent.document.getElementById("FCACHELIST").innerHTML;
		var nowData=1;//当前是否有已配置数据，默认为有(1)
		if(nowHTML.indexOf("未设置任何页面缓存")!=-1)nowData=0;
		if(nowData==0){
			addROWID=1;
		}else{
			addROWID=parseInt(tabROWS)+1;
		}

				ADDHTML=ADDHTML+"<tr ID=\"fcache"+ReturnData.Wid+"TR\"><td width=\"100%\">"+"\n";
				ADDHTML=ADDHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"  onMouseOver=\"javascript:this.style.backgroundColor='#EFF5FB'\" onMouseOut=\"javascript:this.style.backgroundColor='#FFFFFF'\">"+"\n";
				
				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td width=\"60\" rowspan=\"6\" align=\"center\" ID=\"fcacheIndexNO"+ReturnData.Wid+"TD\" class=\"IDTD\">"+addROWID+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td width=\"140\" class=\"objTitle\">缓存地址URL：</td>"+"\n";
				ADDHTML=ADDHTML+"			<td ID=\"fcacheUrl"+ReturnData.Wid+"TD\" class=\"underLine\">"+Url+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td width=\"100\" onclick=\"fcachemodiBOX('"+ReturnData.Wid+"')\"  style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">"+"[修改配置]</td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";
				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td class=\"objTitle\">URL匹配规则：</td>"+"\n";
				ADDHTML=ADDHTML+"			<td ID=\"fcacheIcase"+ReturnData.Wid+"TD\" class=\"normal\">"+Rules+"（匹配时"+Icase+"大小写）"+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td onclick=\"fcachedelCONBOX('"+ReturnData.Wid+"')\"  style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">[删除配置]</td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";



				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td class=\"objTitle\">超时周期：</td>"+"\n";
				ADDHTML=ADDHTML+"			<td ID=\"fcacheExpire"+ReturnData.Wid+"TD\" class=\"normal\">"+Expire+""+Unit+""+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td onclick=\"fcacheupPOST('"+ReturnData.Wid+"')\" style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">[进行上移]</td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";
				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td class=\"objTitle\">忽略Set\-Cookie：</td>"+"\n";
				ADDHTML=ADDHTML+"			<td ID=\"fcacheIcookie"+ReturnData.Wid+"TD\" class=\"normal\">"+Icookie+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td onclick=\"fcachedownPOST('"+ReturnData.Wid+"')\" style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">[进行下移]</td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";
				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td class=\"objTitle\">开放权限：</td>"+"\n";
				ADDHTML=ADDHTML+"			<td ID=\"fcacheOlimit"+ReturnData.Wid+"TD\" class=\"normal\">"+Olimit+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td>&nbsp;</td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";
				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td class=\"objTitle\">"+"备注说明："+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td ID=\"fcacheNote"+ReturnData.Wid+"TD\" class=\"note\">"+Note+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td></td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";

				ADDHTML=ADDHTML+"	</table>"+"\n";
				ADDHTML=ADDHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n";
				ADDHTML=ADDHTML+"		<tr><td width=\"100%\" height=\"5\" background=\"image/line-5px.gif\"></td></tr>";
				ADDHTML=ADDHTML+"	</table>"+"\n";
		
				ADDHTML=ADDHTML+"</td></tr>"+"\n";

		//alert(ADDHTML);
		//============================================================
		//获取当前内容，将新加内容进行拼接，写回	
		if(nowData==0){
			var LISTHTML="<table ID=\"fcacheTAB\" width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n"+ADDHTML+"\n"+"<FCACHELISTEND></table>";
		}else{
			if(Sys.ie){
				var SPLITCHAR="<FCACHELISTEND>";
			}else{
				var SPLITCHAR="<fcachelistend>";
			}
	
			nowHTML=nowHTML.split(SPLITCHAR)[0];
			var LISTHTML=nowHTML+ADDHTML+"<FCACHELISTEND></table>";
		}
		//alert(LISTHTML);
		parent.document.getElementById("FCACHELIST").innerHTML=LISTHTML;
		//============================================================		

		var boxURL="msg.htm?9.8";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		parent.document.documentElement.scrollTop=parent.document.documentElement.scrollHeight;
	}
	document.getElementById("fcacheADDbutton").src="image/fcache-add-button.gif";	//修改BUTTON
}

function fcacheviewset(ReturnData){				//获取页面缓存配置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?9.9";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		if(ReturnData.NumOfLists==0){
			var boxURL="msg.htm?10.0";
			showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		}else{
			var Wid=ReturnData.Lists[0].Wid;
			document.getElementById("Url").value=ReturnData.Lists[0].Url;
			var Icase=ReturnData.Lists[0].Icase;
			var IcaseOBJ=document.getElementsByName("Icase");
			for(i=0;i<IcaseOBJ.length;i++){
				if(IcaseOBJ[i].value==Icase)IcaseOBJ[i].checked=true;
			}
			var Rules=ReturnData.Lists[0].Rules;
			var RulesOBJ=document.getElementsByName("Rules");
			for(i=0;i<RulesOBJ.length;i++){
				if(RulesOBJ[i].value==Rules)RulesOBJ[i].checked=true;
			}
			document.getElementById("Expire").value=ReturnData.Lists[0].Expire;
			var Unit=ReturnData.Lists[0].Unit;
			var UnitOBJ=document.getElementsByName("Unit");
			for(i=0;i<UnitOBJ.length;i++){
				if(UnitOBJ[i].value==Unit)UnitOBJ[i].checked=true;
			}
			var Icookie=ReturnData.Lists[0].Icookie;
			var IcookieOBJ=document.getElementsByName("Icookie");
			for(i=0;i<IcookieOBJ.length;i++){
				if(IcookieOBJ[i].value==Icookie)IcookieOBJ[i].checked=true;
			}
			var Olimit=ReturnData.Lists[0].Olimit;
			var OlimitOBJ=document.getElementsByName("Olimit");
			for(i=0;i<OlimitOBJ.length;i++){
				if(OlimitOBJ[i].value==Olimit)OlimitOBJ[i].checked=true;
			}
			document.getElementById("Note").value=ReturnData.Lists[0].Note;
			
		}
	}
}


function fcachemodi(ReturnData){					//修改页面缓存配置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL==""){
			var boxURL="msg.htm?10.1";
			if(ReturnData.ErrorNo==31)boxURL="msg.htm?10.11";
		}
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var boxURL="msg.htm?10.2";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		//============================================
		//修改列表中内容
		var Wid=ReturnData.Wid;
		var Url=document.getElementById("Url").value;
		var Expire=document.getElementById("Expire").value;
		var IcaseOBJ=document.getElementsByName("Icase");
			for(i=0;i<IcaseOBJ.length;i++){
				if(IcaseOBJ[i].checked==true)var Icase=IcaseOBJ[i].value;
			}//Icase 	是否忽略大小写 不忽略(0), 忽略(1), 缺省(0);
			if(Icase==0)Icase="不忽略";
			if(Icase==1)Icase="忽略";
		var RulesOBJ=document.getElementsByName("Rules");
			for(i=0;i<RulesOBJ.length;i++){
				if(RulesOBJ[i].checked==true)var Rules=RulesOBJ[i].value;
			}//Rules 	Url匹配规则, 通配符匹配(0), 正则表达式匹配(1), 精确匹配(2), 缺省(0);
			if(Rules==0)Rules="通配符匹配";
			if(Rules==1)Rules="正则表达式匹配";
			if(Rules==2)Rules=" 精确匹配";
		var UnitOBJ=document.getElementsByName("Unit");
			for(i=0;i<UnitOBJ.length;i++){
				if(UnitOBJ[i].checked==true)var Unit=UnitOBJ[i].value;
			}//Unit 	时间单位, 天(0), 小时(1), 分钟(2), 秒(3), 缺省(0);
			if(Unit==0)Unit="天";
			if(Unit==1)Unit="小时";
			if(Unit==2)Unit="分钟";
			if(Unit==3)Unit="秒";
		var IcookieOBJ=document.getElementsByName("Icookie");
			for(i=0;i<IcookieOBJ.length;i++){
				if(IcookieOBJ[i].checked==true)var Icookie=IcookieOBJ[i].value;
			}//Icookie  是否忽略 Cookie 不忽略(0), 忽略(1), 缺省(1);
			if(Icookie==0)Icookie="缓存时不忽略";
			if(Icookie==1)Icookie="缓存时忽略";
		var OlimitOBJ=document.getElementsByName("Olimit");
			for(i=0;i<OlimitOBJ.length;i++){
				if(OlimitOBJ[i].checked==true)var Olimit=OlimitOBJ[i].value;
			}//Olimit  开放权限 所有用户 登录用户  游客用户;
			if(Olimit==0)Olimit="所有用户";
			if(Olimit==1)Olimit="登录用户";
			if(Olimit==2)Olimit="游客用户";
		var Note=document.getElementById("Note").value;
		
		parent.document.getElementById("fcacheUrl"+Wid+"TD").innerHTML=Url;
		parent.document.getElementById("fcacheIcase"+Wid+"TD").innerHTML=Rules+"（匹配时"+Icase+"大小写）";
		//parent.document.getElementById("fcacheRules"+Wid+"TD").innerHTML=Rules;
		parent.document.getElementById("fcacheExpire"+Wid+"TD").innerHTML=Expire+Unit;
		//parent.document.getElementById("fcacheUnit"+Wid+"TD").innerHTML=Unit;
		parent.document.getElementById("fcacheIcookie"+Wid+"TD").innerHTML=Icookie;
		parent.document.getElementById("fcacheOlimit"+Wid+"TD").innerHTML=Olimit;
		parent.document.getElementById("fcacheNote"+Wid+"TD").innerHTML=Note;
	}
	document.getElementById("fcacheMODIbutton").src="image/fcache-modi-button.gif";
}

function fcachedel(ReturnData){						//删除页面缓存
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?10.3";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var strTR=document.getElementById("fcache"+ReturnData.Wid+"TR").rowIndex;
		var strTAB=document.getElementById("fcacheTAB");
		strTAB.deleteRow(strTR);
		resetIndexNO('fcache','0',1);			//重新排序
		var boxURL="msg.htm?10.4";;
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}
}

function fcacheup(ReturnData){						//页面缓存上移
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?10.6";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		moveUp('fcache',ReturnData.Wid,'10.7');
	}
}

function fcachedown(ReturnData){					//页面缓存下移
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?10.8";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		moveDown('fcache',ReturnData.Wid,'10.9');
	}
}

//===========================================================================================================
//以下为拒绝缓存部分

function rcachelist(ReturnData){					//获取当前拒绝缓存列表
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?11.0";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var LISTHTML="";
		if(ReturnData.NumOfLists==0){
			LISTHTML="<tr><td width=\"100%\" height=\"300\" align=\"center\">当前未设置任何拒绝缓存，请使用页面右下角的添加拒绝缓存功能进行添加。</td></tr>";
		}else{
			for(var i=0;i<ReturnData.NumOfLists;i++){
				if(ReturnData.Lists[i].Icase==0)var Icase="不忽略";		//是否忽略大小写，0：不忽略；1：忽略;
				if(ReturnData.Lists[i].Icase==1)var Icase="忽略";
				if(ReturnData.Lists[i].Rules==0)var Rules="通配符匹配";	//Rules 	Url匹配规则, 通配符匹配(0), 正则表达式匹配(1), 精确匹配(2), 缺省(0);	
				if(ReturnData.Lists[i].Rules==1)var Rules="正则表达式匹配";
				if(ReturnData.Lists[i].Rules==2)var Rules="精确匹配";
				if(ReturnData.Lists[i].Olimit==0)var Olimit="拒绝缓存到公共缓存";	//Olimit  开放权限 所有用户 登录用户 游客用户
				if(ReturnData.Lists[i].Olimit==1)var Olimit="拒绝缓存到会员缓存";
				if(ReturnData.Lists[i].Olimit==2)var Olimit="拒绝缓存到游客缓存";
				LISTHTML=LISTHTML+"<tr ID=\"rcache"+ReturnData.Lists[i].Wid+"TR\"><td width=\"100%\">"+"\n";
				LISTHTML=LISTHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"  onMouseOver=\"javascript:this.style.backgroundColor='#EFF5FB'\" onMouseOut=\"javascript:this.style.backgroundColor='#FFFFFF'\">"+"\n";
			
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"60\" rowspan=\"4\" align=\"center\" ID=\"rcacheIndexNO"+ReturnData.Lists[i].Wid+"TD\" class=\"IDTD\">"+parseInt(i+1)+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"140\" class=\"objTitle\">缓存地址URL：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"\" ID=\"rcacheUrl"+ReturnData.Lists[i].Wid+"TD\" class=\"underLine\">"+ReturnData.Lists[i].Url+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"100\" onclick=\"rcachemodiBOX('"+ReturnData.Lists[i].Wid+"')\" style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">"+"[修改配置]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">URL匹配规则：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"rcacheIcase"+ReturnData.Lists[i].Wid+"TD\" class=\"normal\">"+Rules+"（匹配时"+Icase+"大小写）"+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td onclick=\"rcachedelCONBOX('"+ReturnData.Lists[i].Wid+"')\" style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">[删除配置]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">开放权限：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"rcacheOlimit"+ReturnData.Lists[i].Wid+"TD\" class=\"normal\">"+Olimit+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td onclick=\"rcacheupPOST('"+ReturnData.Lists[i].Wid+"')\" style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">[进行上移]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">"+"备注说明："+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"rcacheNote"+ReturnData.Lists[i].Wid+"TD\" class=\"note\">"+ReturnData.Lists[i].Note+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td onclick=\"rcachedownPOST('"+ReturnData.Lists[i].Wid+"')\" style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">[进行下移]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";

				LISTHTML=LISTHTML+"	</table>"+"\n";
				LISTHTML=LISTHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n";
				LISTHTML=LISTHTML+"		<tr><td width=\"100%\" height=\"5\" background=\"image/line-5px.gif\"></td></tr>";
				LISTHTML=LISTHTML+"	</table>"+"\n";
				
				LISTHTML=LISTHTML+"</td></tr>"+"\n";
			}
		}
		LISTHTML="<table ID=\"rcacheTAB\" width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n"+LISTHTML+"\n"+"<RCACHELISTEND></table>"+"\n";
		document.getElementById("RCACHELIST").innerHTML=LISTHTML;
		//alert(LISTHTML);
	}
}

function rcacheadd(ReturnData){						//添加拒绝缓存
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL==""){
			var boxURL="msg.htm?11.1";
			if(ReturnData.ErrorNo==30)boxURL="msg.htm?11.11";
		}
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		//============================================================
		//重新获取值，添加进当前列表
		var Url=document.getElementById("Url").value;
		var IcaseOBJ=document.getElementsByName("Icase");
			for(i=0;i<IcaseOBJ.length;i++){
				if(IcaseOBJ[i].checked==true)var Icase=IcaseOBJ[i].value;
			}//是否忽略大小写，0：不忽略；1：忽略;
			if(Icase==0)Icase="不忽略";				
			if(Icase==1)Icase="忽略";
		var RulesOBJ=document.getElementsByName("Rules");
			for(i=0;i<RulesOBJ.length;i++){
				if(RulesOBJ[i].checked==true)var Rules=RulesOBJ[i].value;
			}//Url匹配规则, 通配符匹配(0), 正则表达式匹配(1), 精确匹配(2), 缺省(0);
			if(Rules==0)Rules="通配符匹配";					
			if(Rules==1)Rules="正则表达式匹配";
			if(Rules==2)Rules="精确匹配";
		var OlimitOBJ=document.getElementsByName("Olimit");
			for(i=0;i<OlimitOBJ.length;i++){
				if(OlimitOBJ[i].checked==true)var Olimit=OlimitOBJ[i].value;
			}//Olimit  开放权限 所有用户 登录用户  游客用户
			if(Olimit==0)Olimit="拒绝缓存到公共缓存";					
			if(Olimit==1)Olimit="拒绝缓存到会员缓存";
			if(Olimit==2)Olimit="拒绝缓存到游客缓存";
		var Note=document.getElementById("Note").value;

		//对新添加拒绝缓存HTML代码进行拼接
		//============================================================
		var ADDHTML="";
		var tabROWS=parent.document.getElementById("rcacheTAB").rows.length;
		var nowHTML=parent.document.getElementById("RCACHELIST").innerHTML;
		var nowData=1;//当前是否有已配置数据，默认为有(1)
		if(nowHTML.indexOf("未设置任何拒绝缓存")!=-1)nowData=0;
		if(nowData==0){
			addROWID=1;
		}else{
			addROWID=parseInt(tabROWS)+1;
		}

				ADDHTML=ADDHTML+"<tr ID=\"rcache"+ReturnData.Wid+"TR\"><td width=\"100%\">"+"\n";
				ADDHTML=ADDHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"  onMouseOver=\"javascript:this.style.backgroundColor='#EFF5FB'\" onMouseOut=\"javascript:this.style.backgroundColor='#FFFFFF'\">"+"\n";
				
				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td width=\"60\" rowspan=\"4\" align=\"center\" ID=\"rcacheIndexNO"+ReturnData.Wid+"TD\" class=\"IDTD\">"+addROWID+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td width=\"140\" class=\"objTitle\">缓存地址URL：</td>"+"\n";
				ADDHTML=ADDHTML+"			<td width=\"\" ID=\"rcacheUrl"+ReturnData.Wid+"TD\" class=\"underLine\">"+Url+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td width=\"100\" onclick=\"rcachemodiBOX('"+ReturnData.Wid+"')\" style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">"+"[修改配置]</td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";
				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td class=\"objTitle\">URL匹配规则：</td>"+"\n";
				ADDHTML=ADDHTML+"			<td ID=\"rcacheIcase"+ReturnData.Wid+"TD\" class=\"normal\">"+Rules+"（匹配时"+Icase+"大小写）"+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td onclick=\"rcachedelCONBOX('"+ReturnData.Wid+"')\" style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">[删除配置]</td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";
				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td class=\"objTitle\">开放权限：</td>"+"\n";
				ADDHTML=ADDHTML+"			<td ID=\"rcacheOlimit"+ReturnData.Wid+"TD\" class=\"normal\">"+Olimit+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td onclick=\"rcacheupPOST('"+ReturnData.Wid+"')\" style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">[进行上移]</td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";
				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td class=\"objTitle\">"+"备注说明："+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td ID=\"rcacheNote"+ReturnData.Wid+"TD\" class=\"note\">"+Note+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td onclick=\"rcachedownPOST('"+ReturnData.Wid+"')\" style=\"cursor:pointer;\" class=\"underLine\" align=\"center\">[进行下移]</td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";

				ADDHTML=ADDHTML+"	</table>"+"\n";
				ADDHTML=ADDHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n";
				ADDHTML=ADDHTML+"		<tr><td width=\"100%\" height=\"5\" background=\"image/line-5px.gif\"></td></tr>";
				ADDHTML=ADDHTML+"	</table>"+"\n";
				
				ADDHTML=ADDHTML+"</td></tr>"+"\n";

		//alert(ADDHTML);
		//============================================================
		//获取当前内容，将新加内容进行拼接，写回	
		if(nowData==0){
			var LISTHTML="<table ID=\"rcacheTAB\" width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n"+ADDHTML+"\n"+"<RCACHELISTEND></table>";
		}else{
			if(Sys.ie){
				var SPLITCHAR="<RCACHELISTEND>";
			}else{
				var SPLITCHAR="<rcachelistend>";
			}
	
			nowHTML=nowHTML.split(SPLITCHAR)[0];
			var LISTHTML=nowHTML+ADDHTML+"<RCACHELISTEND></table>";
		}
		//alert(LISTHTML);
		parent.document.getElementById("RCACHELIST").innerHTML=LISTHTML;
		//============================================================		

		var boxURL="msg.htm?11.2";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		parent.document.documentElement.scrollTop=parent.document.documentElement.scrollHeight;
	}
	document.getElementById("rcacheADDbutton").src="image/rcache-add-button.gif";	//修改BUTTON
}

function rcacheviewset(ReturnData){				//获取拒绝缓存配置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?11.3";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		if(ReturnData.NumOfLists==0){
			var boxURL="msg.htm?11.4";
			showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		}else{
			var Wid=ReturnData.Lists[0].Wid;
			document.getElementById("Url").value=ReturnData.Lists[0].Url;
			var Icase=ReturnData.Lists[0].Icase;
			var IcaseOBJ=document.getElementsByName("Icase");
				for(i=0;i<IcaseOBJ.length;i++){
					if(IcaseOBJ[i].value==Icase)IcaseOBJ[i].checked=true;
				}
			var Rules=ReturnData.Lists[0].Rules;
			var RulesOBJ=document.getElementsByName("Rules");
				for(i=0;i<RulesOBJ.length;i++){
					if(RulesOBJ[i].value==Rules)RulesOBJ[i].checked=true;
				}	
			var Olimit=ReturnData.Lists[0].Olimit;
			var OlimitOBJ=document.getElementsByName("Olimit");
				for(i=0;i<OlimitOBJ.length;i++){
					if(OlimitOBJ[i].value==Olimit)OlimitOBJ[i].checked=true;
				}
			document.getElementById("Note").value=ReturnData.Lists[0].Note;
			
		}
	}
}
function rcachemodi(ReturnData){					//修改拒绝缓存配置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL==""){
			var boxURL="msg.htm?11.5";
			if(ReturnData.ErrorNo==31)boxURL="msg.htm?11.51";
		}
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var boxURL="msg.htm?11.6";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		//============================================
		//修改列表中内容
		var Wid=ReturnData.Wid;
		var Url=document.getElementById("Url").value;
		var IcaseOBJ=document.getElementsByName("Icase");
			for(i=0;i<IcaseOBJ.length;i++){
				if(IcaseOBJ[i].checked==true)var Icase=IcaseOBJ[i].value;
			}//Icase 	是否忽略大小写 不忽略(0), 忽略(1), 缺省(0);
			if(Icase==0)Icase="不忽略";
			if(Icase==1)Icase="忽略";
		var RulesOBJ=document.getElementsByName("Rules");
			for(i=0;i<RulesOBJ.length;i++){
				if(RulesOBJ[i].checked==true)var Rules=RulesOBJ[i].value;
			}//Rules 	Url匹配规则, 通配符匹配(0), 正则表达式匹配(1), 精确匹配(2), 缺省(0);
			if(Rules==0)Rules="通配符匹配";
			if(Rules==1)Rules="正则表达式匹配";
			if(Rules==2)Rules=" 精确匹配";
		var OlimitOBJ=document.getElementsByName("Olimit");
			for(i=0;i<OlimitOBJ.length;i++){
				if(OlimitOBJ[i].checked==true)var Olimit=OlimitOBJ[i].value;
			}//Olimit  开放权限 所有用户 登录用户  游客用户;
			if(Olimit==0)Olimit="拒绝缓存到公共缓存";
			if(Olimit==1)Olimit="拒绝缓存到会员缓存";
			if(Olimit==2)Olimit="拒绝缓存到游客缓存";
		var Note=document.getElementById("Note").value;

		parent.document.getElementById("rcacheUrl"+Wid+"TD").innerHTML=Url;
		parent.document.getElementById("rcacheIcase"+Wid+"TD").innerHTML=Rules+"（匹配时"+Icase+"大小写）";
		//parent.document.getElementById("rcacheRules"+Wid+"TD").innerHTML=Rules;
		parent.document.getElementById("rcacheOlimit"+Wid+"TD").innerHTML=Olimit;
		parent.document.getElementById("rcacheNote"+Wid+"TD").innerHTML=Note;
	}
	document.getElementById("rcacheMODIbutton").src="image/rcache-modi-button.gif";
}
function rcachedel(ReturnData){					//删除拒绝缓存
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?11.7";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var strTAB=document.getElementById("rcacheTAB");
		var strTR=document.getElementById("rcache"+ReturnData.Wid+"TR").rowIndex;
		strTAB.deleteRow(strTR);
		resetIndexNO('rcache','0',1);			//重新排序
		var boxURL="msg.htm?11.8";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}
}

function rcacheup(ReturnData){						//拒绝缓存上移
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?12.0";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		moveUp('rcache',ReturnData.Wid,'12.1');
	}
}

function rcachedown(ReturnData){					//拒绝缓存下移
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?12.2";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		moveDown('rcache',ReturnData.Wid,'12.3');
	}
}

//===========================================================================================================
//以下为会话缓存部分
function scachelist(ReturnData){					//获取当前会话缓存列表
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?12.4";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var LISTHTML="";
		if(ReturnData.NumOfLists==0){
			LISTHTML="<tr><td width=\"100%\" height=\"300\" align=\"center\">当前未设置任何会话缓存，请使用页面右下角的添加会话缓存功能进行添加。</td></tr>";
		}else{
			for(var i=0;i<ReturnData.NumOfLists;i++){
				if(ReturnData.Lists[i].Icase==0)var Icase="不忽略";		//是否忽略大小写，0：不忽略；1：忽略;
				if(ReturnData.Lists[i].Icase==1)var Icase="忽略";
				if(ReturnData.Lists[i].Rules==0)var Rules="通配符匹配";	//通配符匹配(0), 正则表达式匹配(1), 精确匹配(2)	
				if(ReturnData.Lists[i].Rules==1)var Rules="正则表达式匹配";
				if(ReturnData.Lists[i].Rules==2)var Rules="精确匹配";
				
				LISTHTML=LISTHTML+"<tr ID=\"scache"+ReturnData.Lists[i].Wid+"TR\"><td width=\"100%\">"+"\n";
				LISTHTML=LISTHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"  onMouseOver=\"javascript:this.style.backgroundColor='#EFF5FB'\" onMouseOut=\"javascript:this.style.backgroundColor='#FFFFFF'\">"+"\n";
			
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"60\" rowspan=\"5\" align=\"center\" ID=\"scacheIndexNO"+ReturnData.Lists[i].Wid+"TD\" class=\"IDTD\">"+parseInt(i+1)+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"140\" class=\"objTitle\">登录验证地址：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"\" ID=\"scacheActionUrl"+ReturnData.Lists[i].Wid+"TD\" class=\"underLine\">"+ReturnData.Lists[i].ActionUrl+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td width=\"100\" onclick=\"scachemodiBOX('"+ReturnData.Lists[i].Wid+"')\" style=\"cursor:pointer;text-align:center;\" class=\"underLine\">"+"[修改配置]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">URL匹配规则：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"scacheIcase"+ReturnData.Lists[i].Wid+"TD\" class=\"normal\">"+Rules+"（匹配时"+Icase+"大小写）"+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td onclick=\"scachedelCONBOX('"+ReturnData.Lists[i].Wid+"')\" style=\"cursor:pointer;text-align:center;\" class=\"underLine\">[删除配置]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">会话ID变量名：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"scacheSetCookieSessionID"+ReturnData.Lists[i].Wid+"TD\" class=\"normal\">"+ReturnData.Lists[i].SetCookieSessionID+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td onclick=\"scacheupPOST('"+ReturnData.Lists[i].Wid+"')\" class=\"underLine\" style=\"cursor:pointer;text-align:center;\">[进行上移]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">缓存周期：</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"scacheSessionExpire"+ReturnData.Lists[i].Wid+"TD\" class=\"normal\">"+ReturnData.Lists[i].SessionExpire+"秒"+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td onclick=\"scachedownPOST('"+ReturnData.Lists[i].Wid+"')\" class=\"underLine\" style=\"cursor:pointer;text-align:center;\">[进行下移]</td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";
				LISTHTML=LISTHTML+"		<tr>"+"\n";
				LISTHTML=LISTHTML+"			<td class=\"objTitle\">"+"备注说明："+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td ID=\"scacheNote"+ReturnData.Lists[i].Wid+"TD\" class=\"note\">"+ReturnData.Lists[i].Note+"</td>"+"\n";
				LISTHTML=LISTHTML+"			<td></td>"+"\n";
				LISTHTML=LISTHTML+"		</tr>"+"\n";

				LISTHTML=LISTHTML+"	</table>"+"\n";
				LISTHTML=LISTHTML+"	<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n";
				LISTHTML=LISTHTML+"		<tr><td width=\"100%\" height=\"5\" background=\"image/line-5px.gif\"></td></tr>";
				LISTHTML=LISTHTML+"	</table>"+"\n";
				
				LISTHTML=LISTHTML+"</td></tr>"+"\n";
			}
		}
		LISTHTML="<table ID=\"scacheTAB\" width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n"+LISTHTML+"\n"+"<SCACHELISTEND></table>"+"\n";
		document.getElementById("SCACHELIST").innerHTML=LISTHTML;
		//alert(LISTHTML);
	}
}

function scacheadd(ReturnData){						//添加会话缓存
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL==""){
			var boxURL="msg.htm?12.5";
			if(ReturnData.ErrorNo==30)boxURL="msg.htm?12.51";
		}
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		//============================================================
		//重新获取值，添加进当前列表
		var ActionUrl=document.getElementById("ActionUrl").value;
		var IcaseOBJ=document.getElementsByName("Icase");
			for(i=0;i<IcaseOBJ.length;i++){
				if(IcaseOBJ[i].checked==true)var Icase=IcaseOBJ[i].value;
			}//是否忽略大小写，0：不忽略；1：忽略;
			if(Icase==0)Icase="不忽略";				
			if(Icase==1)Icase="忽略";
		var RulesOBJ=document.getElementsByName("Rules");
			for(i=0;i<RulesOBJ.length;i++){
				if(RulesOBJ[i].checked==true)var Rules=RulesOBJ[i].value;
			}//Url匹配规则, 通配符匹配(0), 正则表达式匹配(1), 精确匹配(2), 缺省(0);
			if(Rules==0)Rules="通配符匹配";					
			if(Rules==1)Rules="正则表达式匹配";
			if(Rules==2)Rules="精确匹配";
		var SetCookieSessionID=document.getElementById("SetCookieSessionID").value;
		var SessionExpire=document.getElementById("SessionExpire").value;
		var Note=document.getElementById("Note").value;

		//对新添加会话缓存HTML代码进行拼接
		//============================================================
		var ADDHTML="";
		var tabROWS=parent.document.getElementById("scacheTAB").rows.length;
		var nowHTML=parent.document.getElementById("SCACHELIST").innerHTML;
		var nowData=1;//当前是否有已配置数据，默认为有(1)
		if(nowHTML.indexOf("未设置任何会话缓存")!=-1)nowData=0;
		if(nowData==0){
			addROWID=1;
		}else{
			addROWID=parseInt(tabROWS)+1;
		}
				ADDHTML=ADDHTML+"<tr ID=\"scache"+ReturnData.Wid+"TR\"><td width=\"100%\">"+"\n";
				ADDHTML=ADDHTML+"	<table  width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"  onMouseOver=\"javascript:this.style.backgroundColor='#EFF5FB'\" onMouseOut=\"javascript:this.style.backgroundColor='#FFFFFF'\">"+"\n";
				
				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td width=\"60\" rowspan=\"5\" align=\"center\" ID=\"scacheIndexNO"+ReturnData.Wid+"TD\" class=\"IDTD\">"+addROWID+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td width=\"140\" class=\"objTitle\">登录验证地址：</td>"+"\n";
				ADDHTML=ADDHTML+"			<td width=\"\" ID=\"scacheActionUrl"+ReturnData.Wid+"TD\" class=\"underLine\">"+ActionUrl+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td width=\"100\" onclick=\"scachemodiBOX('"+ReturnData.Wid+"')\" style=\"cursor:pointer;text-align:center;\" class=\"underLine\">"+"[修改配置]</td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";
				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td class=\"objTitle\">URL匹配规则：</td>"+"\n";
				ADDHTML=ADDHTML+"			<td ID=\"scacheIcase"+ReturnData.Wid+"TD\" class=\"normal\">"+Rules+"（匹配时"+Icase+"大小写）"+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td onclick=\"scachedelCONBOX('"+ReturnData.Wid+"')\" style=\"cursor:pointer;text-align:center;\" class=\"underLine\">[删除配置]</td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";
				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td class=\"objTitle\">会话ID变量名：</td>"+"\n";
				ADDHTML=ADDHTML+"			<td ID=\"scacheSetCookieSessionID"+ReturnData.Wid+"TD\" class=\"normal\">"+SetCookieSessionID+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td onclick=\"scacheupPOST('"+ReturnData.Wid+"')\" class=\"underLine\" style=\"cursor:pointer;text-align:center;\">[进行上移]</td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";
				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td class=\"objTitle\">缓存周期：</td>"+"\n";
				ADDHTML=ADDHTML+"			<td ID=\"scacheSessionExpire"+ReturnData.Wid+"TD\" class=\"normal\">"+SessionExpire+"秒"+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td onclick=\"scachedownPOST('"+ReturnData.Wid+"')\" class=\"underLine\" style=\"cursor:pointer;text-align:center;\">[进行下移]</td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";
				ADDHTML=ADDHTML+"		<tr>"+"\n";
				ADDHTML=ADDHTML+"			<td class=\"objTitle\">"+"备注说明："+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td ID=\"scacheNote"+ReturnData.Wid+"TD\" class=\"note\">"+Note+"</td>"+"\n";
				ADDHTML=ADDHTML+"			<td></td>"+"\n";
				ADDHTML=ADDHTML+"		</tr>"+"\n";
				
				ADDHTML=ADDHTML+"	</table>"+"\n";
				ADDHTML=ADDHTML+"	<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n";
				ADDHTML=ADDHTML+"		<tr><td width=\"100%\" height=\"5\" background=\"image/line-5px.gif\"></td></tr>";
				ADDHTML=ADDHTML+"	</table>"+"\n";
				
				ADDHTML=ADDHTML+"</td></tr>"+"\n";

		//alert(ADDHTML);
		//============================================================
		//获取当前内容，将新加内容进行拼接，写回	
		
		if(nowData==0){
			var LISTHTML="<table ID=\"scacheTAB\" width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"+"\n"+ADDHTML+"\n"+"<SCACHELISTEND></table>";
		}else{
			if(Sys.ie){
				var SPLITCHAR="<SCACHELISTEND>";
			}else{
				var SPLITCHAR="<scachelistend>";
			}
	
			nowHTML=nowHTML.split(SPLITCHAR)[0];
			var LISTHTML=nowHTML+ADDHTML+"<SCACHELISTEND></table>";
		}
		//alert(LISTHTML);
		parent.document.getElementById("SCACHELIST").innerHTML=LISTHTML;
		//============================================================		

		var boxURL="msg.htm?12.6";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		parent.document.documentElement.scrollTop=parent.document.documentElement.scrollHeight;
	}
	document.getElementById("scacheADDbutton").src="image/scache-add-button.gif";	//修改BUTTON
}

function scacheviewset(ReturnData){					//获取会话缓存配置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?12.7";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		if(ReturnData.NumOfLists==0){
			var boxURL="msg.htm?12.8";
			showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		}else{
			var Wid=ReturnData.Lists[0].Wid;
			document.getElementById("ActionUrl").value=ReturnData.Lists[0].ActionUrl;
			var Icase=ReturnData.Lists[0].Icase;
			var IcaseOBJ=document.getElementsByName("Icase");
				for(i=0;i<IcaseOBJ.length;i++){
					if(IcaseOBJ[i].value==Icase)IcaseOBJ[i].checked=true;
				}
			var Rules=ReturnData.Lists[0].Rules;
			var RulesOBJ=document.getElementsByName("Rules");
				for(i=0;i<RulesOBJ.length;i++){
					if(RulesOBJ[i].value==Rules)RulesOBJ[i].checked=true;
				}	
			document.getElementById("SetCookieSessionID").value=ReturnData.Lists[0].SetCookieSessionID;
			document.getElementById("SessionExpire").value=ReturnData.Lists[0].SessionExpire;
			document.getElementById("Note").value=ReturnData.Lists[0].Note;
			
		}
	}
}
function scachemodi(ReturnData){					//修改会话缓存配置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL==""){
			var boxURL="msg.htm?12.9";
			if(ReturnData.ErrorNo==31)boxURL="msg.htm?12.91";
		}
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var boxURL="msg.htm?13.0";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		//============================================
		//修改列表中内容
		var Wid=ReturnData.Wid;
		var ActionUrl=document.getElementById("ActionUrl").value;
		var IcaseOBJ=document.getElementsByName("Icase");
			for(i=0;i<IcaseOBJ.length;i++){
				if(IcaseOBJ[i].checked==true)var Icase=IcaseOBJ[i].value;
			}//Icase 	是否忽略大小写 不忽略(0), 忽略(1), 缺省(0);
			if(Icase==0)Icase="不忽略";
			if(Icase==1)Icase="忽略";
		var RulesOBJ=document.getElementsByName("Rules");
			for(i=0;i<RulesOBJ.length;i++){
				if(RulesOBJ[i].checked==true)var Rules=RulesOBJ[i].value;
			}//Rules 	Url匹配规则, 通配符匹配(0), 正则表达式匹配(1), 精确匹配(2), 缺省(0);
			if(Rules==0)Rules="通配符匹配";
			if(Rules==1)Rules="正则表达式匹配";
			if(Rules==2)Rules=" 精确匹配";
		var SetCookieSessionID=document.getElementById("SetCookieSessionID").value;
		var SessionExpire=document.getElementById("SessionExpire").value;
		var Note=document.getElementById("Note").value;

		parent.document.getElementById("scacheActionUrl"+Wid+"TD").innerHTML=ActionUrl;
		parent.document.getElementById("scacheIcase"+Wid+"TD").innerHTML=Rules+"（匹配时"+Icase+"大小写）";
		//parent.document.getElementById("scacheRules"+Wid+"TD").innerHTML=Rules;
		parent.document.getElementById("scacheSetCookieSessionID"+Wid+"TD").innerHTML=SetCookieSessionID;
		parent.document.getElementById("scacheSessionExpire"+Wid+"TD").innerHTML=SessionExpire +"秒";
		parent.document.getElementById("scacheNote"+Wid+"TD").innerHTML=Note;
	}
	document.getElementById("scacheMODIbutton").src="image/scache-modi-button.gif";
}

function scachedel(ReturnData){					//删除会话缓存
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?13.1";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var strTR=document.getElementById("scache"+ReturnData.Wid+"TR").rowIndex;
		var strTAB=document.getElementById("scacheTAB");
		strTAB.deleteRow(strTR);
		
		resetIndexNO('scache','0',1);			//重新排序		
		
		var boxURL="msg.htm?13.2";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}
}

function scacheup(ReturnData){						//会话缓存上移
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?13.4";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		moveUp('scache',ReturnData.Wid,'13.5');
	}
}

function scachedown(ReturnData){					//会话缓存下移
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?13.6";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		moveDown('scache',ReturnData.Wid,'13.7');
	}
}

//===========================================================================================================
//以下为清除缓存部分
function icacheclean(ReturnData){					//清除智能缓存
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?13.9";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var boxURL="msg.htm?14.0";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}
}function fcacheclean(ReturnData){					//清除页面缓存
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?14.2";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var boxURL="msg.htm?14.3";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}
}
function allcacheclean(ReturnData){					//清除所有缓存
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?14.5";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var boxURL="msg.htm?14.6";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}
}
function scacheclean(ReturnData){					//清除会话缓存
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?14.8";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var boxURL="msg.htm?14.9";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}
}
function thiscacheclean(ReturnData){				//按条件清除缓存
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL==""){
			var boxURL="msg.htm?15.1";
			if(ReturnData.ErrorNo==32)boxURL="msg.htm?15.11";
		}
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var boxURL="msg.htm?15.2";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}
	document.getElementById("thiscacheCLEANbutton").src="image/thiscache-clean-button.gif";
}



function passmodi(ReturnData){						//修改密码
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?15.5";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var boxURL="msg.htm?15.6";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}
	document.getElementById("passMODIButton").src="image/pass-modi-button.gif";
}

function rthlist(ReturnData){						//获取实时监控配置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?15.7";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		rthARR=ReturnData;
		//alert(ReturnData);
		//重组数据，调用ACPList函数显示ACP层
		ACPList("RequestUrl",rthARR);
	}
}

function rthadd(ReturnData){						//添加实时监控配置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?15.8";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var boxURL="msg.htm?15.9";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
		parent.rthgetlist();//重新载入
	}
}

function rthdel(ReturnData,rthID){					//删除实时监控配置
//alert(ReturnData.Return);
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?16.1";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var strTAB=document.getElementById(ACPTABID);
		var strTR=document.getElementById("RT"+rthID+"TR").rowIndex;
		strTAB.deleteRow(strTR);
	}
}

function toolsiplook(ReturnData){					//查看IP地址地理位置
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?16.2";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var Location=ReturnData.Location;
		document.getElementById("iplocation").innerHTML="地理位置: " + Location;
	}
	document.getElementById("iplookButton").src="image/iplook-button.gif";
}

function toolstestcache(ReturnData){				//缓存测试工具
	if(ReturnData.Return=="False"){
		var boxURL=chkErr(ReturnData.ErrorNo);
		if(boxURL=="")boxURL="msg.htm?16.5";
		showMSGBOX('',350,100,BT,BL,120,boxURL,'操作提示:');
	}else{
		var CacheFlag=ReturnData.CacheFlag;
		if(CacheFlag==10)CacheFlag="测试结果: 此 Url 允许但还无被页面缓存.";
		if(CacheFlag==11)CacheFlag="测试结果: 此 Url 允许并已经被页面缓存.";
		if(CacheFlag==12)CacheFlag="测试结果: 此 Url 被拒绝缓存.";
		if(CacheFlag==13)CacheFlag="测试结果: 此 Url 属于会员登录验证地址(属于会话缓存设定), 此页面拒绝被缓存.";
		if(CacheFlag==14)CacheFlag="测试结果: Fikker 将根据网站的 HTTP 返回头(Pragma, Date, Expire 和 Cache-Control)决定是否缓存和缓存时长(智能缓存).";
	document.getElementById("cacheFlag").innerHTML=CacheFlag;
	}
	document.getElementById("testcacheButton").src="image/testcache-button.gif";
}
