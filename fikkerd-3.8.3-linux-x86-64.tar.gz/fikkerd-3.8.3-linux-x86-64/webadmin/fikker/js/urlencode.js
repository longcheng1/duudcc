﻿function UrlEncode(str){ 
	return encodeURIComponent(str);
}
function UrlDecode(str){
	return decodeURIComponent(str);
} 
