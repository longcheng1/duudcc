﻿//massage_box:提示层
//mask:遮盖层,用于锁屏
//msgBOXTitle:提示层标题,如不设置则显示操作提示
//msgBOXURL:提示层内嵌套的URL,可以直接用于打开地址.如果是POST的话,可以做中转页,中转页获取要提交的FORM名称后再将Parent的FORM进行SUBMIT操作
//注意:提交FORM的POST TARGET设置为msgBOXURL
//例子:
//1:直接将地址在msgBOX的iframe中打开
//openURL="WOW_GB_Action.asp?Action=" + ACT + "&ZY=" + ZY + "&ID=" + ID
//showMSGBOX('true','400','250',openURL,msgBOXTitle)
//[锁屏][宽][高][嵌入URL地址][msgBOX标题]
//2:将FORM POST
//用于提交的FORM <form action="WOW_GB_Action.asp" method="post" name="SETKC_<%=i%>" target="msgBOXURL">注意设置TARGET为msgBOXURL
//openURL="FormSubmit.asp?FormName=" + FormName
//showMSGBOX('true','400','250',openURL,msgBOXTitle)
//FormSubmit.asp文件如下:
//=======================================================================
//FormName=request("FormName")
//response.write "<script>parent." & FormName & ".submit();<\"/script>"
//=======================================================================


//设置应用层
document.writeln("<style>");
document.writeln("#massage_box {");
document.writeln("position: absolute;");
document.writeln("z-index: 2;");
document.writeln("clear:both;");
//document.writeln("visibility: hidden;");
document.writeln("display:none;");
document.writeln("table {color:#666666;}");
document.writeln("a:link,a:hover,a:active,a:visited{color: #1875C6; text-decoration: none;}");
document.writeln("}");

document.writeln("#mask {");
document.writeln("position: absolute;");
document.writeln("top: 0;");
document.writeln("left: 0;");
document.writeln("width: expression(body.scrollWidth);");
document.writeln("height: expression(body.scrollHeight);");
document.writeln("background: #666;");
document.writeln("filter: ALPHA(opacity=60);");
document.writeln("z-index: 1;");
document.writeln("visibility: hidden;");
document.writeln("display: none;");
document.writeln("}");

document.writeln(".msgTitle {");
document.writeln("font-size:14px;color: #666666;");
document.writeln("a:link,a:hover,a:active,a:visited{color: #1875C6; text-decoration: none;}");
document.writeln("}");
document.writeln("</style>");

document.writeln("<div id=\"massage_box\">")
document.writeln("<table border=\"0\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\" bgcolor=\"FFFFFF\">");
document.writeln("<tr>");
document.writeln( "	<td width=\"16\" height=\"28\"><img src=\"image/T-L.gif\"></td>");
document.writeln( "	<td width=\"100%\" ID=\"msgBOXTitle\" class=\"msgTitle\" background=\"image/T-M.gif\" style=padding-left:6px;></td>");
document.writeln( "	<td width=\"35\" background=\"image/T-M.gif\"><a href=\"javascript:closeMSGBOX()\"><span style=\"font-family:宋体\;font-size:14px;\">×</span></a></td>");
document.writeln( "	<td width=\"16\"><img src=\"image/T-R.gif\"></td>");
document.writeln("</tr>");

document.writeln("<tr>");
document.writeln("	<td background=\"image/M-L.gif\"></td>");
document.writeln("	<td colspan=\"2\" id=\"boxM\" style=\"background:#ffffff;\"><iframe marginheight=\"0\" marginwidth=\"0\" frameborder=\"0\" width=\"100%\" height=\"100%\" scrolling=\"auto\" src=\"\" id=\"msgBOXURL\" name=\"msgBOXURL\"></iframe></td>");
document.writeln("	<td background=\"image/M-R.gif\"></td>");
document.writeln("</tr>");
document.writeln("<tr>");
document.writeln("	<td background=\"image/B-L.gif\" height=\"4\"></td>");
document.writeln("	<td colspan=\"2\" background=\"image/B-M.gif\"></td>");
document.writeln("	<td background=\"image/B-R.gif\"></td>");
document.writeln("</tr>");
document.writeln("</table>");
document.writeln("</div>");
document.writeln("<div id=\"mask\"></div>");

//获得浏览器版本号(by discuz)
function browserVersion(types) {
	var other = 1;
	for(i in types) {
		var v = types[i] ? types[i] : i;
		if(USERAGENT.indexOf(v) != -1) {
			var re = new RegExp(v + '(\\/|\\s)([\\d\\.]+)', 'ig');
			var matches = re.exec(USERAGENT);
			var ver = matches != null ? matches[2] : 0;
			other = ver !== 0 && v != 'mozilla' ? 0 : other;
		}else {
			var ver = 0;
		}
		eval('BROWSER.' + i + '= ver');
		//alert('BROWSER.' + i + '=' + ver); /*调试浏览器版本显示*/
	}
	BROWSER.other = other;
}

var BROWSER = {};
var USERAGENT = navigator.userAgent.toLowerCase();
browserVersion({'ie':'msie','firefox':'','chrome':'','opera':'','safari':'','mozilla':'','webkit':'','maxthon':'','qq':'qqbrowser'});
if(BROWSER.safari) {
	BROWSER.firefox = true;
}
BROWSER.opera = BROWSER.opera ? opera.version() : 0;

//显示层
function showMSGBOX(ifmask,boxw,boxh,boxt,boxl,boxMh,boxurl,msgBOXTitle){
//boxh为嵌入页面iframe高度
//alert(boxurl);
	maskOBJ=document.getElementById("mask"); 
	if(ifmask=="true"){
		maskOBJ.style.visibility="visible";		//锁屏
		maskOBJ.style.display="block";
		document.body.style.overflow="hidden";		//隐藏滚动条
	}
	if(msgBOXTitle==""||msgBOXTitle==undefined)msgBOXTitle="操作提示:";
	titleOBJ=document.getElementById('msgBOXTitle');	//消息BOX的TITLE
	showOBJ=document.getElementById('massage_box');

	var boxLEFT;
	var boxTOP;

	//不设置boxl和boxh的话，提示框剧中
	if(boxl==""){
		showOBJ.style.left=document.body.clientWidth/2-boxw/2 + "px";
	}else{
		showOBJ.style.left=boxl + "px";
	} 

	if(boxt==""){
		//alert("document.body.scrollTop:"+document.body.scrollTop);
		//alert("document.documentElement.scrollTop:"+document.documentElement.scrollTop);
		//alert("document.body.clientHeight:"+document.body.clientHeight);
		//alert("document.documentElement.clientHeight:"+document.documentElement.clientHeight);
		//alert("boxh:"+boxh);
		if(BROWSER.chrome || BROWSER.webkit || BROWSER.safari)
		showOBJ.style.top=document.body.scrollTop+(document.documentElement.clientHeight/2-boxh/2)-10 + "px";
		else
		showOBJ.style.top=document.documentElement.scrollTop+(document.documentElement.clientHeight/2-boxh/2)-10 + "px";
		//alert("boxT:"+showOBJ.style.top);
	}else{
		showOBJ.style.top=boxt + "px";
	}
	
	if(boxMh!="")ciframeH(boxMh);
	showOBJ.style.display="block";
	showOBJ.style.visibility="visible";

	//在style为block后，设置高度有效
	showOBJ.style.width=boxw+"px";
	showOBJ.style.height=boxh+"px";
	
	document.getElementById("msgBOXURL").style.height=boxh+"px";

	//设置标题
	titleOBJ.innerHTML=msgBOXTitle;

	//嵌套页面
	msgBOXURLOBJ=document.getElementById("msgBOXURL"); 
	msgBOXURLOBJ.src=boxurl;

	//setTimeout("closeMSGBOX()",3000);			//定时关闭
}
//关闭层
function closeMSGBOX(){
	maskOBJ=document.getElementById("mask"); 
	showOBJ=document.getElementById("massage_box");
	maskOBJ.style.visibility="hidden";
	maskOBJ.style.display="none";
	showOBJ.style.visibility="hidden";
	showOBJ.style.display="none";
	document.getElementById("msgBOXURL").src="";
	//document.body.style.overflow="auto";
	document.body.style.overflowX="hidden";
}

//设置IFRAME高
function ciframeH(ih){
	strOBJ=document.getElementById("msgBOXURL");
	strOBJ.style.height=ih + "px";
}


//滚动条回顶部
function FloatTop(){
	document.body.scrollTop=0 + "px";
}

//禁止横向滚动条
//document.body.style.overflowX="hidden";
//document.body.style.overflowY="true";
//页面打开后自动设置纵向滚动条
//document.body.style.overflow="auto";